<?php
require_once 'includes/session_check.php';
// Allow both admin and coordinator to access this page
if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'coordinator') {
    header('Location: index.php');
    exit;
}
require_once 'includes/db.php';

if (!isset($_GET['quiz_id']) || !is_numeric($_GET['quiz_id'])) {
    header('Location: manage_quizzes.php');
    exit;
}
$quiz_id = $_GET['quiz_id'];
$message = '';

// THIS PHP LOGIC DOES NOT NEED TO CHANGE
// It is already designed to handle `options[]` as an array and `is_correct` as an index (0-3).
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['question_text'])) {
    $question_text = trim($_POST['question_text']);
    $options = $_POST['options'];
    $correct_option_index = $_POST['is_correct'];
    
    $conn->begin_transaction();
    try {
        $stmt_q = $conn->prepare("INSERT INTO questions (quiz_id, question_text) VALUES (?, ?)");
        $stmt_q->bind_param("is", $quiz_id, $question_text);
        $stmt_q->execute();
        $question_id = $conn->insert_id;
        
        $stmt_o = $conn->prepare("INSERT INTO options (question_id, option_text, is_correct) VALUES (?, ?, ?)");
        foreach ($options as $index => $option_text) {
            if (empty(trim($option_text))) continue;
            $is_correct = ($index == $correct_option_index) ? 1 : 0;
            $stmt_o->bind_param("isi", $question_id, $option_text, $is_correct);
            $stmt_o->execute();
        }
        $conn->commit();
        $message = '<div class="alert alert-success">Question added successfully.</div>';
    } catch (mysqli_sql_exception $exception) {
        $conn->rollback();
        $message = '<div class="alert alert-danger">Error: Could not add the question. ' . $exception->getMessage() . '</div>';
    }
}

// Fetch quiz and question data (no changes here)
$quiz_info_stmt = $conn->prepare("SELECT title FROM quizzes WHERE id = ?");
$quiz_info_stmt->bind_param("i", $quiz_id);
$quiz_info_stmt->execute();
$quiz_info = $quiz_info_stmt->get_result()->fetch_assoc();
$pageTitle = "Manage Questions for " . htmlspecialchars($quiz_info['title']);

$sql = "SELECT q.id as q_id, q.question_text, o.option_text, o.is_correct FROM questions q JOIN options o ON q.id = o.question_id WHERE q.quiz_id = ? ORDER BY q.id, o.id";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $quiz_id);
$stmt->execute();
$result = $stmt->get_result();
$questions_with_options = [];
while ($row = $result->fetch_assoc()) {
    $questions_with_options[$row['q_id']]['question_text'] = $row['question_text'];
    $questions_with_options[$row['q_id']]['options'][] = ['text' => $row['option_text'], 'is_correct' => $row['is_correct']];
}

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<h1 class="page-title">Manage Questions for Quiz:</h1>
<h2 class="text-muted mb-4 fs-4"><?= htmlspecialchars($quiz_info['title']); ?></h2>
<?= $message; ?>

<!-- ========================= UPDATED FORM SECTION ========================= -->
<div class="card mb-4">
    <div class="card-header bg-accent">
        <i class="fas fa-plus-circle"></i> Create New Question
    </div>
    <div class="card-body">
        <form action="add_questions.php?quiz_id=<?= $quiz_id; ?>" method="post">
            <div class="mb-3">
                <label for="question_text" class="form-label"><strong>Question Text</strong></label>
                <textarea class="form-control" name="question_text" id="question_text" rows="2" required></textarea>
            </div>
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="option_a" class="form-label">Option A</label>
                    <input type="text" class="form-control" name="options[]" id="option_a" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="option_b" class="form-label">Option B</label>
                    <input type="text" class="form-control" name="options[]" id="option_b" required>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="option_c" class="form-label">Option C</label>
                    <input type="text" class="form-control" name="options[]" id="option_c" required>
                </div>
                 <div class="col-md-6 mb-3">
                    <label for="option_d" class="form-label">Option D</label>
                    <input type="text" class="form-control" name="options[]" id="option_d" required>
                </div>
            </div>
            
            <div class="mb-3">
                <label for="correct_option" class="form-label"><strong>Correct Option</strong></label>
                <select class="form-select" name="is_correct" id="correct_option" required>
                    <option value="" disabled selected>-- Select the correct answer --</option>
                    <option value="0">A</option>
                    <option value="1">B</option>
                    <option value="2">C</option>
                    <option value="3">D</option>
                </select>
            </div>
            
            <hr>
            <button type="submit" class="btn btn-primary">Add This Question</button>
            <a href="manage_quizzes.php" class="btn btn-secondary">Back to Quizzes</a>
        </form>
    </div>
</div>
<!-- ======================= END OF UPDATED FORM SECTION ======================= -->


<!-- List of Existing Questions (No changes here) -->
<div class="card">
    <div class="card-header"><i class="fas fa-list-ul"></i> Questions Already in this Quiz</div>
    <div class="card-body">
        <?php if (!empty($questions_with_options)): ?>
            <div class="accordion" id="questionsAccordion">
                <?php $q_number = 1; foreach ($questions_with_options as $question_id => $data): ?>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="heading<?= $question_id ?>">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?= $question_id ?>">
                            <strong>Question <?= $q_number++ ?>:</strong> <?= htmlspecialchars($data['question_text']) ?>
                        </button>
                    </h2>
                    <div id="collapse<?= $question_id ?>" class="accordion-collapse collapse" data-bs-parent="#questionsAccordion">
                        <div class="accordion-body">
                            <ul class="list-group">
                                <?php foreach ($data['options'] as $option): ?>
                                    <li class="list-group-item <?= $option['is_correct'] ? 'list-group-item-success' : '' ?>">
                                        <?= htmlspecialchars($option['text']) ?>
                                        <?php if ($option['is_correct']): ?>
                                            <span class="badge bg-success float-end"><i class="fas fa-check"></i> Correct</span>
                                        <?php endif; ?>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="text-center">No questions have been added to this quiz yet.</p>
        <?php endif; ?>
    </div>
</div>


<?php $conn->close(); include 'includes/footer.php'; ?>