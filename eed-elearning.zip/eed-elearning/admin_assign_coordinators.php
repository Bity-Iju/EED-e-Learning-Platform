<?php
require_once 'includes/session_check.php';
require_role('admin');
require_once 'includes/db.php';

$message = '';

// --- Handle Un-assigning a Coordinator ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['unassign_coordinator'])) {
    $coordinator_id = $_POST['coordinator_id'] ?? 0;
    if ($coordinator_id > 0) {
        // Set the unit_id to NULL to unassign
        $stmt = $conn->prepare("UPDATE users SET unit_id = NULL WHERE id = ? AND role = 'coordinator'");
        $stmt->bind_param("i", $coordinator_id);
        if ($stmt->execute()) {
            $message = '<div class="alert alert-info">Coordinator has been unassigned.</div>';
        } else {
            $message = '<div class="alert alert-danger">Error unassigning the coordinator.</div>';
        }
        $stmt->close();
    }
}


// --- Handle Assigning a Unit ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_unit'])) {
    $coordinator_id = $_POST['coordinator_id'] ?? 0;
    $unit_id = $_POST['unit_id'] ?? 0;

    if ($coordinator_id > 0 && $unit_id > 0) {
        $stmt = $conn->prepare("UPDATE users SET unit_id = ? WHERE id = ? AND role = 'coordinator'");
        $stmt->bind_param("ii", $unit_id, $coordinator_id);
        if ($stmt->execute()) {
            $message = '<div class="alert alert-success">Coordinator has been successfully assigned.</div>';
        } else {
            $message = '<div class="alert alert-danger">Error updating assignment. This unit may already be assigned.</div>';
        }
        $stmt->close();
    } else {
        $message = '<div class="alert alert-warning">Invalid coordinator or unit selected.</div>';
    }
}


// --- Fetch Data for Display ---

// 1. Get all coordinators and their assigned unit
$coordinators_sql = "SELECT u.id, u.full_name, u.unit_id, un.unit_name 
                     FROM users u 
                     LEFT JOIN units un ON u.unit_id = un.id 
                     WHERE u.role = 'coordinator' 
                     ORDER BY u.full_name ASC";
$coordinators_result = $conn->query($coordinators_sql);

// 2. Get all available units
$units_sql = "SELECT id, unit_name FROM units ORDER BY unit_name ASC";
$units_result = $conn->query($units_sql);
$all_units = $units_result->fetch_all(MYSQLI_ASSOC);

// 3. NEW: Get a list of all unit IDs that are already assigned to a coordinator
$assigned_units_sql = "SELECT DISTINCT unit_id FROM users WHERE role = 'coordinator' AND unit_id IS NOT NULL";
$assigned_unit_ids = array_column($conn->query($assigned_units_sql)->fetch_all(MYSQLI_ASSOC), 'unit_id');


$pageTitle = "Assign Coordinators";
include 'includes/header.php';
include 'includes/sidebar.php';
?>

<h1 class="page-title">Assign Coordinators to Units</h1>
<p class="lead">Assign a coordinator to a unit. A unit can only be assigned to one coordinator at a time.</p>
<?= $message ?>

<div class="card shadow">
    <div class="card-header bg-accent"><i class="fas fa-user-cog"></i> Coordinator Assignments</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle">
                <thead class="thead-light"><tr><th>Coordinator Name</th><th>Current Unit</th><th style="width: 50%;">Actions</th></tr></thead>
                <tbody>
                    <?php if ($coordinators_result && $coordinators_result->num_rows > 0): ?>
                        <?php while ($coordinator = $coordinators_result->fetch_assoc()): ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($coordinator['full_name']) ?></strong></td>
                                <td>
                                    <?php if ($coordinator['unit_name']) echo '<span class="badge bg-success">' . htmlspecialchars($coordinator['unit_name']) . '</span>';
                                          else echo '<span class="badge bg-secondary">Unassigned</span>'; ?>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <!-- Assignment Form -->
                                        <form action="admin_assign_coordinators.php" method="post" class="d-flex flex-grow-1">
                                            <input type="hidden" name="coordinator_id" value="<?= $coordinator['id'] ?>">
                                            <select name="unit_id" class="form-select me-2" required>
                                                <option value="" disabled selected>-- Select a unit --</option>
                                                <?php foreach ($all_units as $unit):
                                                    // Determine if the option should be disabled
                                                    $is_assigned_to_another = in_array($unit['id'], $assigned_unit_ids) && $unit['id'] != $coordinator['unit_id'];
                                                    $disabled_attr = $is_assigned_to_another ? 'disabled' : '';
                                                ?>
                                                    <option value="<?= $unit['id'] ?>" 
                                                        <?= ($unit['id'] == $coordinator['unit_id']) ? 'selected' : '' ?>
                                                        <?= $disabled_attr ?>
                                                    >
                                                        <?= htmlspecialchars($unit['unit_name']) ?> <?= $is_assigned_to_another ? '(Assigned)' : '' ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                            <button type="submit" name="assign_unit" class="btn btn-primary btn-sm">Assign</button>
                                        </form>

                                        <!-- Unassign Button Form -->
                                        <?php if ($coordinator['unit_id']): // Only show the unassign button if they have a unit ?>
                                            <form action="admin_assign_coordinators.php" method="post" class="ms-2">
                                                <input type="hidden" name="coordinator_id" value="<?= $coordinator['id'] ?>">
                                                <button type="submit" name="unassign_coordinator" class="btn btn-secondary btn-sm">Unassign</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="3" class="text-center py-4">No coordinators found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php 
$conn->close();
include 'includes/footer.php'; 
?>