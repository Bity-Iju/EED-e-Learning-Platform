<?php
require_once 'includes/session_check.php';
require_role('admin');
require_once 'includes/db.php';

// --- DATABASE QUERIES FOR STATS ---

// 1. Main summary stats
$student_count = $conn->query("SELECT COUNT(id) as total FROM users WHERE role = 'student'")->fetch_assoc()['total'] ?? 0;
$unit_count = $conn->query("SELECT COUNT(id) as total FROM units")->fetch_assoc()['total'] ?? 0;
$question_count = $conn->query("SELECT COUNT(id) as total FROM questions")->fetch_assoc()['total'] ?? 0;

// 2. Coordinator-specific stats
$assigned_coordinators_result = $conn->query("SELECT COUNT(id) as total FROM users WHERE role = 'coordinator' AND unit_id IS NOT NULL");
$assigned_coordinator_count = $assigned_coordinators_result->fetch_assoc()['total'] ?? 0;

$unassigned_coordinators_result = $conn->query("SELECT COUNT(id) as total FROM users WHERE role = 'coordinator' AND unit_id IS NULL");
$unassigned_coordinator_count = $unassigned_coordinators_result->fetch_assoc()['total'] ?? 0;


$pageTitle = "Admin Dashboard";
include 'includes/header.php';
include 'includes/sidebar.php';
?>

<h1 class="page-title">Administrator Dashboard</h1>
<p class="lead">Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?>. Here is a summary of the platform.</p>

<!-- =============================================== -->
<!-- ALL STATISTIC CARDS NOW IN A SINGLE ROW         -->
<!-- =============================================== -->
<div class="row">
    <!-- Total Students Card -->
    <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
        <div class="card bg-primary text-white shadow h-100 py-2"><div class="card-body"><div class="row no-gutters align-items-center"><div class="col mr-2"><div class="text-xs font-weight-bold text-uppercase mb-1">Total Students</div><div class="h5 mb-0 font-weight-bold"><?= $student_count ?></div></div><div class="col-auto"><i class="fas fa-users fa-2x" style="opacity: 0.7;"></i></div></div></div></div>
    </div>
    <!-- Total Units Card -->
    <div class="col-xl-2 col-lg-4 col-md-6 mb-4">
        <div class="card bg-success text-white shadow h-100 py-2"><div class="card-body"><div class="row no-gutters align-items-center"><div class="col mr-2"><div class="text-xs font-weight-bold text-uppercase mb-1">Total Units</div><div class="h5 mb-0 font-weight-bold"><?= $unit_count ?></div></div><div class="col-auto"><i class="fas fa-book fa-2x" style="opacity: 0.7;"></i></div></div></div></div>
    </div>
    <!-- Total Questions Card -->
    <div class="col-xl-2 col-lg-4 col-md-6 mb-4">
        <div class="card bg-info text-white shadow h-100 py-2"><div class="card-body"><div class="row no-gutters align-items-center"><div class="col mr-2"><div class="text-xs font-weight-bold text-uppercase mb-1">Total Questions</div><div class="h5 mb-0 font-weight-bold"><?= $question_count ?></div></div><div class="col-auto"><i class="fas fa-question-circle fa-2x" style="opacity: 0.7;"></i></div></div></div></div>
    </div>
    <!-- Assigned Coordinators Card -->
    <div class="col-xl-2 col-lg-6 col-md-6 mb-4">
        <div class="card bg-warning text-dark shadow h-100 py-2"><div class="card-body"><div class="row no-gutters align-items-center"><div class="col mr-2"><div class="text-xs font-weight-bold text-uppercase mb-1">Assigned Coordinators</div><div class="h5 mb-0 font-weight-bold"><?= $assigned_coordinator_count ?></div></div><div class="col-auto"><i class="fas fa-user-check fa-2x" style="opacity: 0.5;"></i></div></div></div></div>
    </div>
    <!-- Unassigned Coordinators Card -->
    <div class="col-xl-3 col-lg-6 col-md-12 mb-4">
        <div class="card bg-secondary text-white shadow h-100 py-2"><div class="card-body"><div class="row no-gutters align-items-center"><div class="col mr-2"><div class="text-xs font-weight-bold text-uppercase mb-1">Unassigned Coordinators</div><div class="h5 mb-0 font-weight-bold"><?= $unassigned_coordinator_count ?></div></div><div class="col-auto"><i class="fas fa-user-plus fa-2x" style="opacity: 0.7;"></i></div></div></div></div>
    </div>
</div>


<!-- Unit Quiz Performance Section -->
<div class="mb-4">
    <h2 class="page-title" style="font-size: 1.75rem; margin-bottom: 15px; margin-top: 20px;">Unit Quiz Performance</h2>
    <?php
    $unit_scores_sql = "SELECT u.id AS unit_id, u.unit_name, COUNT(qr.id) AS submission_count, AVG(qr.percentage) AS average_score FROM units u LEFT JOIN quiz_results qr ON u.id = qr.unit_id GROUP BY u.id, u.unit_name ORDER BY u.unit_name ASC";
    $unit_scores_result = $conn->query($unit_scores_sql);
    ?>
    <div class="row">
        <?php if ($unit_scores_result && $unit_scores_result->num_rows > 0): ?>
            <?php while ($unit_data = $unit_scores_result->fetch_assoc()): ?>
                <div class="col-xl-4 col-md-6 mb-4">
                    <div class="card h-100 shadow">
                        <div class="card-header bg-accent"><i class="fas fa-chart-bar"></i><strong><?= htmlspecialchars($unit_data['unit_name']) ?></strong></div>
                        <div class="card-body">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex justify-content-between align-items-center">Submissions<span class="badge bg-primary rounded-pill"><?= (int)$unit_data['submission_count'] ?></span></li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">Average Score<span class="badge bg-success rounded-pill"><?= $unit_data['average_score'] !== null ? round($unit_data['average_score']) . '%' : 'N/A' ?></span></li>
                            </ul>
                            <a href="view_unit_scores.php?unit_id=<?= $unit_data['unit_id'] ?>" class="btn btn-primary btn-sm mt-3">View Detailed Scores</a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col"><div class="alert alert-info">No quiz performance data is available yet.</div></div>
        <?php endif; ?>
    </div>
</div>


<?php
$conn->close();
include 'includes/footer.php';
?>