<?php
require_once 'includes/session_check.php';
require_role('admin');
require_once 'includes/db.php';

$message = '';
// Handle adding a new coordinator
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_coordinator'])) {
    $full_name = trim($_POST['full_name']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $unit_id = $_POST['unit_id'];

    if (empty($full_name) || empty($username) || empty($password) || empty($unit_id)) {
        $message = '<div class="alert alert-danger">All fields are required.</div>';
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $role = 'coordinator';
        $stmt = $conn->prepare("INSERT INTO users (full_name, username, password, role, unit_id) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssi", $full_name, $username, $hashed_password, $role, $unit_id);
        if ($stmt->execute()) {
            $message = '<div class="alert alert-success">Coordinator added successfully.</div>';
        } else {
            $message = '<div class="alert alert-danger">Error: Username may already exist.</div>';
        }
    }
}

// Fetch units for the dropdown
$units_result = $conn->query("SELECT id, unit_name FROM units ORDER BY unit_name");

// Fetch existing coordinators
$coordinators_result = $conn->query("SELECT u.full_name, u.username, un.unit_name FROM users u JOIN units un ON u.unit_id = un.id WHERE u.role = 'coordinator'");

$pageTitle = "Manage Coordinators";
include 'includes/header.php';
include 'includes/sidebar.php';
?>

<h1 class="page-title">Manage Coordinators</h1>
<?= $message ?>

<div class="row">
    <div class="col-md-5 mb-4">
        <div class="card"><div class="card-header bg-accent"><i class="fas fa-user-plus"></i> Add New Coordinator</div><div class="card-body">
            <form action="admin_manage_coordinators.php" method="post">
                <div class="mb-3"><label class="form-label">Full Name</label><input type="text" name="full_name" class="form-control" required></div>
                <div class="mb-3"><label class="form-label">Username</label><input type="text" name="username" class="form-control" required></div>
                <div class="mb-3"><label class="form-label">Password</label><input type="password" name="password" class="form-control" required></div>
                <div class="mb-3"><label class="form-label">Assign to Unit</label><select name="unit_id" class="form-select" required><option disabled selected>-- Select a Unit --</option><?php while($unit=$units_result->fetch_assoc()):?><option value="<?=$unit['id']?>"><?=htmlspecialchars($unit['unit_name'])?></option><?php endwhile;?></select></div>
                <button type="submit" name="add_coordinator" class="btn btn-primary">Add Coordinator</button>
            </form>
        </div></div>
    </div>
    <div class="col-md-7">
        <div class="card"><div class="card-header"><i class="fas fa-user-tie"></i> Existing Coordinators</div><div class="card-body">
            <table class="table table-striped"><thead><tr><th>Name</th><th>Username</th><th>Unit</th></tr></thead><tbody>
                <?php while($coord=$coordinators_result->fetch_assoc()):?>
                <tr><td><?=htmlspecialchars($coord['full_name'])?></td><td><?=htmlspecialchars($coord['username'])?></td><td><?=htmlspecialchars($coord['unit_name'])?></td></tr>
                <?php endwhile;?>
            </tbody></table>
        </div></div>
    </div>
</div>

<?php $conn->close(); include 'includes/footer.php'; ?>