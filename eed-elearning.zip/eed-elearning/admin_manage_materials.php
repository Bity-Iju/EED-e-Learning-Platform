<?php
require_once 'includes/session_check.php';
require_role('admin');
require_once 'includes/db.php';

$message = '';

// --- Handle Deleting a Material ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_material'])) {
    $course_id = $_POST['course_id'];

    // First, get the file path from the DB to delete the actual file
    $stmt = $conn->prepare("SELECT file_path FROM courses WHERE id = ?");
    $stmt->bind_param("i", $course_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $file_to_delete = $row['file_path'];
        
        // Delete the record from the database
        $delete_stmt = $conn->prepare("DELETE FROM courses WHERE id = ?");
        $delete_stmt->bind_param("i", $course_id);
        if ($delete_stmt->execute()) {
            // If DB deletion is successful, delete the file from the server
            if (file_exists($file_to_delete)) {
                unlink($file_to_delete);
            }
            $message = '<div class="alert alert-success">Material deleted successfully.</div>';
        } else {
            $message = '<div class="alert alert-danger">Error deleting material from database.</div>';
        }
        $delete_stmt->close();
    }
    $stmt->close();
}

// --- Handle File Upload ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['material_file'])) {
    $unit_id = $_POST['unit_id'];
    $title = trim($_POST['title']);
    $target_dir = "uploads/";
    // Create the directory if it doesn't exist
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0755, true);
    }
    
    // Sanitize the filename and prepend a unique ID to prevent conflicts
    $file_name = uniqid() . '_' . preg_replace("/[^a-zA-Z0-9._-]/", "", basename($_FILES["material_file"]["name"]));
    $target_file = $target_dir . $file_name;

    if (move_uploaded_file($_FILES["material_file"]["tmp_name"], $target_file)) {
        $stmt = $conn->prepare("INSERT INTO courses (unit_id, title, file_path) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $unit_id, $title, $target_file);
        if ($stmt->execute()) {
            $message = '<div class="alert alert-success">Material uploaded successfully.</div>';
        } else {
            $message = '<div class="alert alert-danger">Database error: ' . htmlspecialchars($stmt->error) . '</div>';
        }
        $stmt->close();
    } else {
        $message = '<div class="alert alert-danger">Sorry, there was an error uploading your file.</div>';
    }
}

// Fetch all units for the dropdown
$units_result = $conn->query("SELECT id, unit_name FROM units ORDER BY unit_name");

$pageTitle = "Admin: Manage Materials";
include 'includes/header.php';
include 'includes/sidebar.php';
?>

<h1 class="page-title">Admin: Manage Course Materials</h1>
<?= $message ?>

<div class="card mb-4">
    <div class="card-header bg-accent"><i class="fas fa-upload"></i> Upload New Material</div>
    <div class="card-body">
        <form action="admin_manage_materials.php" method="post" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">1. Select Unit</label>
                    <select name="unit_id" class="form-select" required>
                        <option value="" disabled selected>-- Select a Unit --</option>
                        <?php mysqli_data_seek($units_result, 0); while ($unit = $units_result->fetch_assoc()) : ?>
                            <option value="<?= $unit['id'] ?>"><?= htmlspecialchars($unit['unit_name']) ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">2. Material Title</label>
                    <input type="text" name="title" class="form-control" required>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">3. Select File (PDF, Video, etc.)</label>
                <input type="file" name="material_file" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Upload Material</button>
        </form>
    </div>
</div>

<!-- NEW: Table to display all uploaded materials -->
<div class="card mt-4">
    <div class="card-header"><i class="fas fa-list-ul"></i> All Uploaded Materials</div>
    <div class="card-body">
        <?php
        // Fetch all materials with their unit names
        $materials_query = "SELECT c.id, c.title, c.file_path, u.unit_name 
                            FROM courses c 
                            JOIN units u ON c.unit_id = u.id 
                            ORDER BY u.unit_name ASC, c.title ASC";
        $all_materials_result = $conn->query($materials_query);
        ?>
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="thead-light">
                    <tr>
                        <th>Unit Name</th>
                        <th>Material Title</th>
                        <th class="text-center" style="width: 200px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($all_materials_result && $all_materials_result->num_rows > 0) : ?>
                        <?php while ($material = $all_materials_result->fetch_assoc()) : ?>
                            <tr>
                                <td><?= htmlspecialchars($material['unit_name']) ?></td>
                                <td><?= htmlspecialchars($material['title']) ?></td>
                                <td class="text-center">
                                    <a href="<?= htmlspecialchars($material['file_path']) ?>" class="btn btn-sm btn-success" download>Download</a>
                                    <form action="admin_manage_materials.php" method="post" onsubmit="return confirm('Are you sure you want to delete this material? This action cannot be undone.');" style="display: inline-block;">
                                        <input type="hidden" name="course_id" value="<?= $material['id'] ?>">
                                        <button type="submit" name="delete_material" class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3" class="text-center">No materials have been uploaded yet.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php
$conn->close();
include 'includes/footer.php';
?>