<?php
require_once 'includes/session_check.php';
require_role('admin');
require_once 'includes/db.php';

$message = '';
// Ensure the selected unit is maintained across form submissions (GET or POST)
$selected_unit_id = $_REQUEST['unit_id'] ?? null;

// Handle removing a question
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_question'])) {
    $question_id = $_POST['question_id'];
    $stmt = $conn->prepare("DELETE FROM questions WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $question_id);
        if ($stmt->execute()) {
            $message = '<div class="alert alert-success">Question removed successfully.</div>';
        } else {
            $message = '<div class="alert alert-danger">Error removing question.</div>';
        }
        $stmt->close();
    } else {
         die('Prepare failed: ' . htmlspecialchars($conn->error));
    }
}

// Handle adding a new question
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_question'])) {
    $unit_id = $_POST['unit_id'];
    $question_text = trim($_POST['question_text']);
    $option_a = trim($_POST['option_a']);
    $option_b = trim($_POST['option_b']);
    $option_c = trim($_POST['option_c']);
    $option_d = trim($_POST['option_d']);
    $correct_answer = trim($_POST['correct_answer']);

    // --- UPDATED VALIDATION: Check for all four options ---
    if (!empty($question_text) && !empty($option_a) && !empty($option_b) && !empty($option_c) && !empty($option_d) && !empty($correct_answer)) {
        $stmt = $conn->prepare("INSERT INTO questions (unit_id, question_text, option_a, option_b, option_c, option_d, correct_answer) VALUES (?, ?, ?, ?, ?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("issssss", $unit_id, $question_text, $option_a, $option_b, $option_c, $option_d, $correct_answer);
            if ($stmt->execute()) {
                $message = '<div class="alert alert-success">Question added successfully.</div>';
            } else {
                $message = '<div class="alert alert-danger">Error adding question: ' . htmlspecialchars($stmt->error) . '</div>';
            }
            $stmt->close();
        } else {
             die('Prepare failed: ' . htmlspecialchars($conn->error));
        }
    } else {
        $message = '<div class="alert alert-warning">Please fill in all required fields. All four options are compulsory.</div>';
    }
}

$units_result = $conn->query("SELECT id, unit_name FROM units ORDER BY unit_name");
$pageTitle = "Admin: Manage Unit Questions";

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<h1 class="page-title">Admin: Manage Unit Questions</h1>
<?= $message ?>

<div class="card mb-4">
    <div class="card-header bg-accent"><i class="fas fa-filter"></i> Select a Unit to Manage Questions</div>
    <div class="card-body">
        <form action="admin_manage_quizzes.php" method="get" id="unitSelectionForm">
            <div class="input-group">
                <select name="unit_id" class="form-select" onchange="document.getElementById('unitSelectionForm').submit()">
                    <option value="" <?= !$selected_unit_id ? 'selected' : '' ?>>-- Select a Unit --</option>
                    <?php mysqli_data_seek($units_result, 0); while ($unit = $units_result->fetch_assoc()) : ?>
                        <option value="<?= $unit['id'] ?>" <?= $selected_unit_id == $unit['id'] ? 'selected' : '' ?>><?= htmlspecialchars($unit['unit_name']) ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
        </form>
    </div>
</div>

<?php if ($selected_unit_id) : // Only show the management interface if a unit is selected ?>
    <div class="row">
        <!-- Add Question Form -->
        <div class="col-lg-5 mb-4">
            <div class="card">
                <div class="card-header"><i class="fas fa-plus-circle"></i> Add New Question</div>
                <div class="card-body">
                    <form action="admin_manage_quizzes.php" method="post">
                        <input type="hidden" name="unit_id" value="<?= $selected_unit_id ?>">
                        <div class="mb-3">
                            <label for="question_text" class="form-label">Question Text</label>
                            <textarea name="question_text" id="question_text" class="form-control" rows="3" required></textarea>
                        </div>
                        <div class="mb-3"><label for="option_a" class="form-label">Option A</label><input type="text" name="option_a" id="option_a" class="form-control" required></div>
                        <div class="mb-3"><label for="option_b" class="form-label">Option B</label><input type="text" name="option_b" id="option_b" class="form-control" required></div>
                        <!-- UPDATED: Option C is now required -->
                        <div class="mb-3"><label for="option_c" class="form-label">Option C</label><input type="text" name="option_c" id="option_c" class="form-control" required></div>
                        <!-- UPDATED: Option D is now required -->
                        <div class="mb-3"><label for="option_d" class="form-label">Option D</label><input type="text" name="option_d" id="option_d" class="form-control" required></div>
                        <div class="mb-3"><label for="correct_answer" class="form-label">Correct Answer</label><select name="correct_answer" id="correct_answer" class="form-select" required><option value="">-- Select --</option><option value="A">A</option><option value="B">B</option><option value="C">C</option><option value="D">D</option></select></div>
                        <button type="submit" name="add_question" class="btn btn-primary">Add Question</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Existing Questions List for Selected Unit -->
        <div class="col-lg-7">
            <div class="card">
                <div class="card-header"><i class="fas fa-list-ul"></i> Existing Questions for Selected Unit</div>
                <div class="card-body">
                    <?php
                    $stmt = $conn->prepare("SELECT id, question_text FROM questions WHERE unit_id = ? ORDER BY id DESC");
                    $stmt->bind_param("i", $selected_unit_id);
                    $stmt->execute();
                    $questions_result = $stmt->get_result();
                    ?>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead><tr><th>Question</th><th style="width: 100px;">Action</th></tr></thead>
                            <tbody>
                                <?php if ($questions_result->num_rows > 0) : ?>
                                    <?php while ($question = $questions_result->fetch_assoc()) : ?>
                                        <tr>
                                            <td><?= htmlspecialchars($question['question_text']) ?></td>
                                            <td>
                                                <form action="admin_manage_quizzes.php" method="post" onsubmit="return confirm('Are you sure you want to delete this question?');">
                                                    <input type="hidden" name="unit_id" value="<?= $selected_unit_id ?>">
                                                    <input type="hidden" name="question_id" value="<?= $question['id'] ?>">
                                                    <button type="submit" name="remove_question" class="btn btn-danger btn-sm">Remove</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr><td colspan="2">No questions found for this unit.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- Table to display all questions from all units -->
<div class="card mt-4">
    <div class="card-header"><i class="fas fa-globe-americas"></i> All Existing Questions (By Unit)</div>
    <div class="card-body">
        <?php
        $all_questions_query = "SELECT q.id, q.question_text, u.unit_name, u.id AS unit_id FROM questions q JOIN units u ON q.unit_id = u.id ORDER BY u.unit_name ASC, q.id DESC";
        $all_questions_result = $conn->query($all_questions_query);
        ?>
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="thead-light">
                    <tr>
                        <th>Unit Name</th>
                        <th>Question</th>
                        <th style="width: 100px;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($all_questions_result && $all_questions_result->num_rows > 0) : ?>
                        <?php while ($question = $all_questions_result->fetch_assoc()) : ?>
                            <tr>
                                <td><?= htmlspecialchars($question['unit_name']) ?></td>
                                <td><?= htmlspecialchars($question['question_text']) ?></td>
                                <td>
                                    <form action="admin_manage_quizzes.php" method="post" onsubmit="return confirm('Are you sure you want to delete this question?');">
                                        <input type="hidden" name="unit_id" value="<?= $question['unit_id'] ?>">
                                        <input type="hidden" name="question_id" value="<?= $question['id'] ?>">
                                        <button type="submit" name="remove_question" class="btn btn-danger btn-sm">Remove</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="3" class="text-center">No questions have been added to any unit yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php
$conn->close();
include 'includes/footer.php';
?>