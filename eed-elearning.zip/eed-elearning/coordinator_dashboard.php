<?php
require_once 'includes/session_check.php';
require_role('coordinator');
require_once 'includes/db.php';

// Get the coordinator's assigned unit from the session
$unit_id = $_SESSION['unit_id'];
$unit_name = $_SESSION['unit_name'];
$pageTitle = "Coordinator Dashboard";

// --- QUERIES FOR THE SUMMARY CARDS ---
$student_count_stmt = $conn->prepare("SELECT COUNT(id) as total FROM users WHERE role = 'student' AND unit_id = ?");
$student_count_stmt->bind_param("i", $unit_id);
$student_count_stmt->execute();
$student_count = $student_count_stmt->get_result()->fetch_assoc()['total'] ?? 0;
$student_count_stmt->close();

$material_count_stmt = $conn->prepare("SELECT COUNT(id) as total FROM courses WHERE unit_id = ?");
$material_count_stmt->bind_param("i", $unit_id);
$material_count_stmt->execute();
$material_count = $material_count_stmt->get_result()->fetch_assoc()['total'] ?? 0;
$material_count_stmt->close();

$question_count_stmt = $conn->prepare("SELECT COUNT(id) as total FROM questions WHERE unit_id = ?");
$question_count_stmt->bind_param("i", $unit_id);
$question_count_stmt->execute();
$question_count = $question_count_stmt->get_result()->fetch_assoc()['total'] ?? 0;
$question_count_stmt->close();

$perf_stmt = $conn->prepare("SELECT COUNT(id) AS submission_count, AVG(percentage) AS average_score FROM quiz_results WHERE unit_id = ?");
$perf_stmt->bind_param("i", $unit_id);
$perf_stmt->execute();
$perf_result = $perf_stmt->get_result()->fetch_assoc();
$submission_count = $perf_result['submission_count'] ?? 0;
$average_score = $perf_result['average_score'] ?? null;
$perf_stmt->close();


// --- NEW: QUERIES FOR THE DETAILED TABLES ---

// 1. Fetch all students assigned to this unit
$assigned_students_stmt = $conn->prepare("SELECT full_name, registration_number FROM users WHERE role = 'student' AND unit_id = ? ORDER BY full_name ASC");
$assigned_students_stmt->bind_param("i", $unit_id);
$assigned_students_stmt->execute();
$assigned_students = $assigned_students_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$assigned_students_stmt->close();

// 2. Fetch all quiz scores for students in this unit
$student_scores_stmt = $conn->prepare("
    SELECT u.full_name, u.registration_number, qr.score, qr.total_questions, qr.percentage, qr.submitted_at
    FROM quiz_results qr
    JOIN users u ON qr.student_id = u.id
    WHERE qr.unit_id = ?
    ORDER BY qr.percentage DESC
");
$student_scores_stmt->bind_param("i", $unit_id);
$student_scores_stmt->execute();
$student_scores = $student_scores_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$student_scores_stmt->close();


include 'includes/header.php';
include 'includes/sidebar.php';
?>

<h1 class="page-title">Coordinator Dashboard</h1>
<p class="lead">Welcome, <?= htmlspecialchars($_SESSION['full_name']); ?>. You are managing the <strong><?= htmlspecialchars($unit_name); ?></strong> unit.</p>

<!-- Summary Cards Row -->
<div class="row">
    <div class="col-xl-3 col-md-6 mb-4"><div class="card bg-primary text-white shadow h-100"><div class="card-body"><div class="row no-gutters align-items-center"><div class="col"><div class="text-xs font-weight-bold text-uppercase mb-1">Students in Unit</div><div class="h5 mb-0 fw-bold"><?= $student_count ?></div></div><div class="col-auto"><i class="fas fa-users fa-2x" style="opacity:0.7"></i></div></div></div></div></div>
    <div class="col-xl-3 col-md-6 mb-4"><div class="card bg-info text-white shadow h-100"><div class="card-body"><div class="row no-gutters align-items-center"><div class="col"><div class="text-xs font-weight-bold text-uppercase mb-1">Unit Materials</div><div class="h5 mb-0 fw-bold"><?= $material_count ?></div></div><div class="col-auto"><i class="fas fa-file-alt fa-2x" style="opacity:0.7"></i></div></div></div></div></div>
    <div class="col-xl-3 col-md-6 mb-4"><div class="card bg-secondary text-white shadow h-100"><div class="card-body"><div class="row no-gutters align-items-center"><div class="col"><div class="text-xs font-weight-bold text-uppercase mb-1">Unit Questions</div><div class="h5 mb-0 fw-bold"><?= $question_count ?></div></div><div class="col-auto"><i class="fas fa-question-circle fa-2x" style="opacity:0.7"></i></div></div></div></div></div>
    <div class="col-xl-3 col-md-6 mb-4"><div class="card bg-success text-white shadow h-100"><div class="card-body"><div class="row no-gutters align-items-center"><div class="col"><div class="text-xs font-weight-bold text-uppercase mb-1">Average Score</div><div class="h5 mb-0 fw-bold"><?= $average_score !== null ? round($average_score).'%' : 'N/A' ?></div></div><div class="col-auto"><i class="fas fa-chart-pie fa-2x" style="opacity:0.7"></i></div></div></div></div></div>
</div>

<!-- ======================================================== -->
<!-- NEW: DETAILED STUDENT AND SCORE INFORMATION TABS         -->
<!-- ======================================================== -->
<div class="card shadow">
    <div class="card-header">
        <ul class="nav nav-tabs card-header-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="students-tab" data-bs-toggle="tab" data-bs-target="#students" type="button" role="tab">Assigned Students</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="scores-tab" data-bs-toggle="tab" data-bs-target="#scores" type="button" role="tab">Student Scores</button>
            </li>
        </ul>
    </div>
    <div class="card-body">
        <div class="tab-content" id="myTabContent">
            <!-- Assigned Students Tab -->
            <div class="tab-pane fade show active" id="students" role="tabpanel">
                <h5 class="card-title">Students Registered in <?= htmlspecialchars($unit_name) ?></h5>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead><tr><th>#</th><th>Full Name</th><th>Registration Number</th></tr></thead>
                        <tbody>
                            <?php if (!empty($assigned_students)): $i = 1; ?>
                                <?php foreach ($assigned_students as $student): ?>
                                    <tr><td><?= $i++ ?></td><td><?= htmlspecialchars($student['full_name']) ?></td><td><?= htmlspecialchars($student['registration_number']) ?></td></tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="3" class="text-center py-4">No students are currently assigned to this unit.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- Student Scores Tab -->
            <div class="tab-pane fade" id="scores" role="tabpanel">
                <h5 class="card-title">Quiz Scores for <?= htmlspecialchars($unit_name) ?></h5>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead><tr><th>Student Name</th><th>Reg. Number</th><th class="text-center">Score</th><th class="text-center">Percentage</th><th>Date Taken</th></tr></thead>
                        <tbody>
                            <?php if (!empty($student_scores)): ?>
                                <?php foreach ($student_scores as $score): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($score['full_name']) ?></td>
                                        <td><?= htmlspecialchars($score['registration_number']) ?></td>
                                        <td class="text-center"><strong><?= (int)$score['score'] ?> / <?= (int)$score['total_questions'] ?></strong></td>
                                        <td class="text-center">
                                            <span class="badge fs-6 p-2 <?php 
                                                if ($score['percentage'] >= 70) echo 'bg-success';
                                                elseif ($score['percentage'] >= 40) echo 'bg-warning text-dark';
                                                else echo 'bg-danger';
                                            ?>">
                                                <?= htmlspecialchars(round($score['percentage'])) ?>%
                                            </span>
                                        </td>
                                        <td><?= date('F j, Y, g:i a', strtotime($score['submitted_at'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="5" class="text-center py-4">No quiz submissions found for this unit.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php 
$conn->close();
include 'includes/footer.php'; 
?>