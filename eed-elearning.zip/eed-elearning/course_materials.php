<?php
require_once 'includes/session_check.php';
require_once 'includes/db.php';

// UPDATED: Use the correct session variables
$student_unit_id = $_SESSION['unit_id'];
$student_unit_name = $_SESSION['unit_name'];
$pageTitle = "Course Materials for " . htmlspecialchars($student_unit_name);

// UPDATED: Query based on the integer unit_id for efficiency and accuracy
$stmt = $conn->prepare("SELECT title, file_path, uploaded_at FROM courses WHERE unit_id = ? ORDER BY uploaded_at DESC");
$stmt->bind_param("i", $student_unit_id); // "i" for integer
$stmt->execute();
$materials = $stmt->get_result();

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<h1 class="page-title">Course Materials: <?php echo htmlspecialchars($student_unit_name); ?></h1>
<div class="card">
    <div class="card-body">
        <p>Here you can find all the reading materials. Click to download.</p>
        <ul class="list-group list-group-flush">
            <?php if ($materials->num_rows > 0): ?>
                <?php while($row = $materials->fetch_assoc()): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <div><i class="fas fa-file-pdf text-danger me-2"></i><?php echo htmlspecialchars($row['title']); ?></div>
                        <a href="<?php echo htmlspecialchars($row['file_path']); ?>" class="btn btn-accent btn-sm" download><i class="fas fa-download"></i> Download</a>
                    </li>
                <?php endwhile; ?>
            <?php else: ?>
                <li class="list-group-item">No materials have been uploaded for this unit yet.</li>
            <?php endif; ?>
        </ul>
    </div>
</div>

<?php 
$stmt->close();
$conn->close();
include 'includes/footer.php'; 
?>