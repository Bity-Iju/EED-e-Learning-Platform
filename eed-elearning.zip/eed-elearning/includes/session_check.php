<?php
session_start();

if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

function require_role($required_role) {
    if ($_SESSION["role"] !== $required_role) {
        header("location: index.php"); 
        exit;
    }
}
?>