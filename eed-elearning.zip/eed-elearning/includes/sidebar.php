<nav id="sidebar">
    <div class="sidebar-header">
        <h3>EED<span>Center</span></h3>
    </div>
    <ul class="list-unstyled components">
        <?php 
        // These variables are available because session_check.php is included first
        $role = $_SESSION['role']; 
        $activePage = basename($_SERVER['PHP_SELF']); 
        ?>

        <?php // --- ADMIN NAVIGATION ---
        if ($role == 'admin'): ?>
            <li class="<?= $activePage == 'admin_dashboard.php' ? 'active' : '' ?>">
                <a href="admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            </li>
            <li class="<?= $activePage == 'admin_manage_units.php' ? 'active' : '' ?>">
                <a href="manage_units.php"><i class="fas fa-book-medical"></i> Manage Units</a>
            </li>
            <li class="<?= $activePage == 'admin_assign_coordinators.php' ? 'active' : '' ?>">
                <a href="admin_assign_coordinators.php"><i class="fas fa-user-cog"></i> Assign Coordinators</a>
            </li>
            <li class="<?= $activePage == 'admin_manage_materials.php' ? 'active' : '' ?>">
                <a href="admin_manage_materials.php"><i class="fas fa-file-upload"></i> Manage Materials</a>
            </li>
            <li class="<?= $activePage == 'admin_manage_quizzes.php' ? 'active' : '' ?>">
                <a href="admin_manage_quizzes.php"><i class="fas fa-question-circle"></i> Manage Questions</a>
            </li>

        <?php // --- COORDINATOR NAVIGATION ---
        elseif ($role == 'coordinator'): ?>
            <li class="<?= $activePage == 'coordinator_dashboard.php' ? 'active' : '' ?>">
                <a href="coordinator_dashboard.php"><i class="fas fa-chalkboard-teacher"></i> Unit Dashboard</a>
            </li>
            <li class="<?= $activePage == 'manage_materials.php' ? 'active' : '' ?>">
                <a href="manage_materials.php"><i class="fas fa-file-upload"></i> Manage Materials</a>
            </li>
            <li class="<?= $activePage == 'manage_quizzes.php' ? 'active' : '' ?>">
                <a href="manage_quizzes.php"><i class="fas fa-question-circle"></i> Manage Questions</a>
            </li>

        <?php // --- STUDENT NAVIGATION ---
        elseif ($role == 'student'): ?>
            <li class="<?= $activePage == 'student_dashboard.php' ? 'active' : '' ?>">
                <a href="student_dashboard.php"><i class="fas fa-tachometer-alt"></i> My Dashboard</a>
            </li>
            <li class="<?= $activePage == 'course_materials.php' ? 'active' : '' ?>">
                <a href="course_materials.php"><i class="fas fa-file-alt"></i> Course Materials</a>
            </li>
            <!-- Updated to keep the quiz link active for both the hub and the quiz itself -->
            <li class="<?= ($activePage == 'take_quiz.php' || $activePage == 'start_quiz.php') ? 'active' : '' ?>">
                <a href="take_quiz.php"><i class="fas fa-pen-square"></i> My Quiz</a>
            </li>
        
        <?php endif; ?>
    </ul>
    
    <ul class="list-unstyled CTAs">
         <li><a href="logout.php" class="btn btn-danger mx-3"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</nav>

<!-- This opening div for the main content area is part of the template layout -->
<div id="content">