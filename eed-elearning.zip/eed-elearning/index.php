<?php
session_start();
// If user is already logged in, redirect them to their respective dashboard
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    if ($_SESSION["role"] === 'student') {
        header("location: student_dashboard.php");
    } else if ($_SESSION["role"] === 'coordinator') {
        header("location: unit.php");
    } else if ($_SESSION["role"] === 'admin') {
        header("location: admin_dashboard.php");
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome to the EED E-Learning Center</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .hero {
            background: linear-gradient(to right, rgba(30, 41, 59, 0.9), rgba(13, 148, 136, 0.9));
            color: white;
            padding: 100px 0;
            display: flex;
            align-items: center;
        }
        .hero h1 { 
            font-weight: 700; 
            font-size: 2.8rem;
        }

        /* --- UPDATED: Logo Styling --- */
        .hero-logo {
            /* 1. Increased logo size */
            width: 160px; 
            height: auto;
            background-color: #ffffff;
            border-radius: 50%;
            /* 2. Reduced the white space (border) around the logo */
            padding: 5px; 
            /* 3. Made the shadow deeper and more noticeable */
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3); 
            flex-shrink: 0;
        }
        
        .skill-image {
            width: 100%;
            height: 250px;
            object-fit: cover;
        }
    </style>
</head>
<body>

    <div class="hero">
        <div class="container">
            <div class="d-flex align-items-center">
                <!-- Logo on the left -->
                <img src="assets/images/logo.png" alt="Federal Polytechnic Mubi Logo" class="hero-logo me-md-5 me-4">
                
                <!-- Text content on the right -->
                <div>
                    <h1>E-Learning Platform for Technical Skills</h1>
                    <p class="lead fs-4 mb-4">EED Center - Federal Polytechnic Mubi</p>
                    <a href="login.php" class="btn btn-light btn-lg fw-bold">Login or Register Now</a>
                </div>
            </div>
        </div>
    </div>

    <!-- "Skills in Action" Image Gallery Section -->
    <div class="container py-5">
        <h2 class="text-center mb-4">Skills in Action</h2>
        <div class="row g-4">
            <!-- Image 1: Bead Making -->
            <div class="col-md-4">
                <div class="card shadow-sm h-100">
                    <img src="assets/images/bead-making.jpg" class="card-img-top skill-image" alt="Women learning bead making">
                    <div class="card-body">
                        <h5 class="card-title text-center">Creative Arts</h5>
                    </div>
                </div>
            </div>

            <!-- Image 2: Workshop -->
            <div class="col-md-4">
                <div class="card shadow-sm h-100">
                    <img src="assets/images/workshop.jpg" class="card-img-top skill-image" alt="Students in a technical workshop">
                     <div class="card-body">
                        <h5 class="card-title text-center">Mechanical Crafts</h5>
                    </div>
                </div>
            </div>

            <!-- Image 3: Sewing -->
            <div class="col-md-4">
                <div class="card shadow-sm h-100">
                    <img src="assets/images/sewing.jpg" class="card-img-top skill-image" alt="Students in a tailoring class">
                     <div class="card-body">
                        <h5 class="card-title text-center">Fashion Design</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="bg-light">
        <div class="container text-center py-5">
            <h2>Our Offered Units</h2>
            <p class="text-muted">We provide training across a wide range of practical skills.</p>
            <div class="d-flex justify-content-center flex-wrap gap-3 mt-4">
                <span class="badge bg-secondary fs-6 p-2">Barbing</span>
                <span class="badge bg-secondary fs-6 p-2">Tailoring</span>
                <span class="badge bg-secondary fs-6 p-2">Solar Installation</span>
                <span class="badge bg-secondary fs-6 p-2">Carpentry</span>
                <span class="badge bg-secondary fs-6 p-2">Hair Dressing</span>
                <span class="badge bg-secondary fs-6 p-2">Bead Making</span>
            </div>
        </div>
    </div>
    
</body>
</html>