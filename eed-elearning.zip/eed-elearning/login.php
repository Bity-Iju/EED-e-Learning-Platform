<?php
session_start();
require_once "includes/db.php";

// Redirect if user is already logged in
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: index.php"); // The index will route them to their correct dashboard
    exit;
}

$login_err = $reg_err = $reg_success = "";
$active_tab = "login"; 

// SECURITY: Check if an admin account already exists to disable further admin registrations.
$admin_check_result = $conn->query("SELECT id FROM users WHERE role = 'admin' LIMIT 1");
$admin_exists = ($admin_check_result && $admin_check_result->num_rows > 0);

// Fetch units for the student registration dropdown
$units_result = $conn->query("SELECT id, unit_name FROM units ORDER BY unit_name");

// --- REGISTRATION LOGIC ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
    $active_tab = "register";
    $full_name = trim($_POST['full_name']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $role = $_POST['role'] ?? '';
    $unit_id = ($role === 'student') ? ($_POST['unit_id'] ?? null) : null;
    $reg_number = ($role === 'student') ? trim($_POST['registration_number']) : null;

    // --- Server-side validation ---
    if(empty($full_name) || empty($username) || empty($password) || empty($role)){
        $reg_err = "Please fill all required fields.";
    } elseif ($role === 'student' && (empty($unit_id) || empty($reg_number))) {
        $reg_err = "Students must provide a registration number and select a unit.";
    } elseif ($role === 'admin' && $admin_exists) {
        $reg_err = "An admin account already exists. Registration as admin is disabled.";
    } else {
        // Prepare an insert statement
        $sql = "INSERT INTO users (full_name, registration_number, username, password, role, unit_id) VALUES (?, ?, ?, ?, ?, ?)";
        if($stmt = $conn->prepare($sql)){
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt->bind_param("sssssi", $full_name, $reg_number, $username, $hashed_password, $role, $unit_id);
            
            if($stmt->execute()){
                $reg_success = "Registration successful! You can now log in using your credentials.";
                $active_tab = "login"; // Switch user to the login tab
            } else { 
                // Handle duplicate entry error for username or registration number
                $reg_err = ($conn->errno == 1062) ? "This username or registration number is already taken." : "Oops! Something went wrong. Please try again."; 
            }
            $stmt->close();
        }
    }
}

// --- LOGIN LOGIC ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $active_tab = "login";
    if(empty(trim($_POST["username"])) || empty(trim($_POST["password"]))){
        $login_err = "Please enter both username and password.";
    } else {
        $username = trim($_POST["username"]);
        
        // --- UPDATED: Fetch `full_name` as well ---
        $sql = "SELECT u.id, u.full_name, u.username, u.password, u.role, u.unit_id, un.unit_name, u.registration_number
                FROM users u 
                LEFT JOIN units un ON u.unit_id = un.id 
                WHERE u.username = ?";
                
        if($stmt = $conn->prepare($sql)){
            $stmt->bind_param("s", $username);
            if($stmt->execute()){
                $result = $stmt->get_result();
                if($result->num_rows == 1){                    
                    $user = $result->fetch_assoc();
                    // Verify password
                    if(password_verify(trim($_POST["password"]), $user['password'])){
                        session_regenerate_id(true); // Security: Regenerate session ID on login
                        
                        // --- UPDATED: Store session variables with correct keys ---
                        $_SESSION["loggedin"] = true;
                        $_SESSION["user_id"] = $user['id']; // CRITICAL FIX: Use 'user_id' key
                        $_SESSION["full_name"] = $user['full_name']; // NEW: Store full name for personalization
                        $_SESSION["username"] = $user['username'];
                        $_SESSION["role"] = $user['role'];
                        $_SESSION["unit_id"] = $user['unit_id'];
                        $_SESSION["unit_name"] = $user['unit_name'];
                        $_SESSION["registration_number"] = $user['registration_number'];
                        
                        // Redirect user to the main index, which will route them to their dashboard
                        header("location: index.php");
                        exit;
                    } else { 
                        $login_err = "The password you entered was not valid."; 
                    }
                } else { 
                    $login_err = "No account found with that username."; 
                }
            } else { 
                $login_err = "Oops! Something went wrong. Please try again later."; 
            }
            $stmt->close();
        }
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login & Register - EED Center</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="auth-container">
        <div class="card auth-card">
            <div class="card-header">
                 <ul class="nav nav-tabs card-header-tabs" id="auth-tabs" role="tablist">
                    <li class="nav-item" role="presentation"><button class="nav-link <?= ($active_tab == 'login' ? 'active' : '') ?>" id="login-tab" data-bs-toggle="tab" data-bs-target="#login-panel" type="button">Login</button></li>
                    <li class="nav-item" role="presentation"><button class="nav-link <?= ($active_tab == 'register' ? 'active' : '') ?>" id="register-tab" data-bs-toggle="tab" data-bs-target="#register-panel" type="button">Register</button></li>
                </ul>
            </div>
            <div class="card-body p-4">
                <div class="tab-content" id="auth-tabs-content">
                    <!-- Login Panel -->
                    <div class="tab-pane fade <?= ($active_tab == 'login' ? 'show active' : '') ?>" id="login-panel">
                        <h4 class="card-title text-center mb-4">Welcome Back!</h4>
                        <?php if(!empty($login_err)) echo '<div class="alert alert-danger">'.$login_err.'</div>'; ?>
                        <?php if(!empty($reg_success)) echo '<div class="alert alert-success">'.$reg_success.'</div>'; ?>
                        <form action="login.php" method="post">
                            <div class="mb-3"><label class="form-label">Username</label><input type="text" name="username" class="form-control" required></div>
                            <div class="mb-3"><label class="form-label">Password</label><input type="password" name="password" class="form-control" required></div>
                            <button type="submit" name="login" class="btn btn-primary w-100 mt-3">Login</button>
                        </form>
                    </div>

                    <!-- Registration Panel -->
                    <div class="tab-pane fade <?= ($active_tab == 'register' ? 'show active' : '') ?>" id="register-panel">
                         <h4 class="card-title text-center mb-4">Create an Account</h4>
                         <?php if(!empty($reg_err)) echo '<div class="alert alert-danger">'.$reg_err.'</div>'; ?>
                         <form action="login.php" method="post" id="registerForm">
                            <div class="mb-3"><label class="form-label">Full Name</label><input type="text" name="full_name" class="form-control" required></div>
                            <div class="mb-3"><label class="form-label">Username</label><input type="text" name="username" class="form-control" required></div>
                            <div class="mb-3"><label class="form-label">Password</label><input type="password" name="password" class="form-control" required></div>
                            
                            <div class="mb-3">
                                <label class="form-label">Register As</label>
                                <select name="role" id="reg-role" class="form-select" required>
                                    <option value="" selected disabled>-- Select a role --</option>
                                    <option value="student">Student</option>
                                    <option value="coordinator">Coordinator</option>
                                    <?php // Conditionally render the Admin option for first-time setup
                                    if (!$admin_exists): ?>
                                        <option value="admin">Admin (First-Time Setup)</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                            
                            <!-- Hidden fields for students, shown via JavaScript -->
                            <div id="student-fields" style="display:none;">
                                <div class="mb-3"><label for="reg-number" class="form-label">Registration Number</label><input type="text" name="registration_number" id="reg-number" class="form-control"></div>
                                <div class="mb-3"><label for="reg-unit" class="form-label">Select Your Unit</label><select name="unit_id" id="reg-unit" class="form-select"><option value="" selected disabled>-- Choose a unit --</option><?php if($units_result) { mysqli_data_seek($units_result, 0); while($unit = $units_result->fetch_assoc()): ?><option value="<?= $unit['id'] ?>"><?= htmlspecialchars($unit['unit_name']) ?></option><?php endwhile; } ?></select></div>
                            </div>
                            <button type="submit" name="register" class="btn btn-primary w-100 mt-3">Register</button>
                         </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const roleSelect = document.getElementById('reg-role');
    const studentFieldsDiv = document.getElementById('student-fields');
    const regNumberInput = document.getElementById('reg-number');
    const unitSelect = document.getElementById('reg-unit');

    function toggleStudentFields() {
        if (roleSelect.value === 'student') {
            studentFieldsDiv.style.display = 'block';
            regNumberInput.required = true;
            unitSelect.required = true;
        } else {
            studentFieldsDiv.style.display = 'none';
            regNumberInput.required = false;
            unitSelect.required = false;
        }
    }
    // Check on load in case the form is re-populated after an error
    toggleStudentFields();
    // Add event listener for changes
    roleSelect.addEventListener('change', toggleStudentFields);
});
</script>
</body>
</html>