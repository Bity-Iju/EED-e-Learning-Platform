<?php
session_start();
$_SESSION = array(); // Unset all session values
session_destroy(); // Destroy the session
header("location: index.php");
exit;
?>