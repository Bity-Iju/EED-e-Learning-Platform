<?php
require_once 'includes/session_check.php';
require_role('coordinator');
require_once 'includes/db.php';

$message = '';
// Get the coordinator's assigned unit ID and name from the session
$unit_id = $_SESSION['unit_id'];
$unit_name = $_SESSION['unit_name'];
$pageTitle = "Manage Materials";

// Handle Deleting a Material
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_material'])) {
    $course_id = $_POST['course_id'];
    $stmt = $conn->prepare("SELECT file_path FROM courses WHERE id = ? AND unit_id = ?");
    $stmt->bind_param("ii", $course_id, $unit_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $delete_stmt = $conn->prepare("DELETE FROM courses WHERE id = ?");
        $delete_stmt->bind_param("i", $course_id);
        if ($delete_stmt->execute()) {
            if (file_exists($row['file_path'])) unlink($row['file_path']);
            $message = '<div class="alert alert-success">Material deleted successfully.</div>';
        }
        $delete_stmt->close();
    }
    $stmt->close();
}

// Handle File Upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['material_file'])) {
    $title = trim($_POST['title']);
    $target_dir = "uploads/";
    if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);
    $file_name = uniqid() . '_' . preg_replace("/[^a-zA-Z0-9._-]/", "", basename($_FILES["material_file"]["name"]));
    $target_file = $target_dir . $file_name;
    if (move_uploaded_file($_FILES["material_file"]["tmp_name"], $target_file)) {
        $stmt = $conn->prepare("INSERT INTO courses (unit_id, title, file_path) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $unit_id, $title, $target_file);
        if ($stmt->execute()) $message = '<div class="alert alert-success">Material uploaded successfully.</div>';
        else $message = '<div class="alert alert-danger">Database error.</div>';
        $stmt->close();
    }
}

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<h1 class="page-title">Manage Course Materials</h1>
<p class="lead">You are managing materials for your assigned unit: <strong><?= htmlspecialchars($unit_name) ?></strong></p>
<?= $message ?>

<div class="card mb-4">
    <div class="card-header bg-accent"><i class="fas fa-upload"></i> Upload New Material</div>
    <div class="card-body">
        <form action="manage_materials.php" method="post" enctype="multipart/form-data">
            <div class="mb-3"><label class="form-label">Material Title</label><input type="text" name="title" class="form-control" required></div>
            <div class="mb-3"><label class="form-label">Select File (PDF, Video, etc.)</label><input type="file" name="material_file" class="form-control" required></div>
            <button type="submit" class="btn btn-primary">Upload Material</button>
        </form>
    </div>
</div>

<div class="card mt-4">
    <div class="card-header"><i class="fas fa-list-ul"></i> Uploaded Materials for Your Unit</div>
    <div class="card-body">
        <?php
        $materials_stmt = $conn->prepare("SELECT id, title, file_path FROM courses WHERE unit_id = ? ORDER BY title ASC");
        $materials_stmt->bind_param("i", $unit_id);
        $materials_stmt->execute();
        $all_materials_result = $materials_stmt->get_result();
        ?>
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="thead-light"><tr><th>Material Title</th><th class="text-center" style="width: 200px;">Actions</th></tr></thead>
                <tbody>
                    <?php if ($all_materials_result->num_rows > 0) : ?>
                        <?php while ($material = $all_materials_result->fetch_assoc()) : ?>
                            <tr>
                                <td><?= htmlspecialchars($material['title']) ?></td>
                                <td class="text-center">
                                    <a href="<?= htmlspecialchars($material['file_path']) ?>" class="btn btn-sm btn-primary" download>Download</a>
                                    <form action="manage_materials.php" method="post" onsubmit="return confirm('Are you sure?');" style="display: inline-block;">
                                        <input type="hidden" name="course_id" value="<?= $material['id'] ?>">
                                        <button type="submit" name="delete_material" class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="2" class="text-center">No materials have been uploaded for this unit yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php 
$conn->close();
include 'includes/footer.php'; 
?>