<?php
require_once 'includes/session_check.php';
require_role('coordinator');
require_once 'includes/db.php';

$message = '';
// Get the coordinator's assigned unit ID and name from the session
$unit_id = $_SESSION['unit_id'];
$unit_name = $_SESSION['unit_name'];
$pageTitle = "Manage Questions";

// Handle removing a question
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_question'])) {
    $question_id = $_POST['question_id'];
    $stmt = $conn->prepare("DELETE FROM questions WHERE id = ? AND unit_id = ?");
    $stmt->bind_param("ii", $question_id, $unit_id);
    if ($stmt->execute()) $message = '<div class="alert alert-success">Question removed.</div>';
    else $message = '<div class="alert alert-danger">Error removing question.</div>';
    $stmt->close();
}

// Handle adding a new question
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_question'])) {
    // (Form validation and insertion logic remains the same as your other file)
    $question_text = trim($_POST['question_text']);
    $option_a = trim($_POST['option_a']);
    $option_b = trim($_POST['option_b']);
    $option_c = trim($_POST['option_c']);
    $option_d = trim($_POST['option_d']);
    $correct_answer = trim($_POST['correct_answer']);
    if (!empty($question_text) && !empty($option_a) && !empty($option_b) && !empty($option_c) && !empty($option_d) && !empty($correct_answer)) {
        $stmt = $conn->prepare("INSERT INTO questions (unit_id, question_text, option_a, option_b, option_c, option_d, correct_answer) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("issssss", $unit_id, $question_text, $option_a, $option_b, $option_c, $option_d, $correct_answer);
        if ($stmt->execute()) $message = '<div class="alert alert-success">Question added.</div>';
        else $message = '<div class="alert alert-danger">Error adding question.</div>';
        $stmt->close();
    } else {
        $message = '<div class="alert alert-warning">All fields are required.</div>';
    }
}

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<h1 class="page-title">Manage Questions</h1>
<p class="lead">You are managing questions for your assigned unit: <strong><?= htmlspecialchars($unit_name) ?></strong></p>
<?= $message ?>

<div class="row">
    <!-- Add Question Form -->
    <div class="col-lg-5 mb-4">
        <div class="card h-100">
            <div class="card-header"><i class="fas fa-plus-circle"></i> Add New Question</div>
            <div class="card-body">
                <form action="manage_quizzes.php" method="post">
                    <div class="mb-3"><label class="form-label">Question Text</label><textarea name="question_text" class="form-control" rows="3" required></textarea></div>
                    <div class="mb-3"><label class="form-label">Option A</label><input type="text" name="option_a" class="form-control" required></div>
                    <div class="mb-3"><label class="form-label">Option B</label><input type="text" name="option_b" class="form-control" required></div>
                    <div class="mb-3"><label class="form-label">Option C</label><input type="text" name="option_c" class="form-control" required></div>
                    <div class="mb-3"><label class="form-label">Option D</label><input type="text" name="option_d" class="form-control" required></div>
                    <div class="mb-3"><label class="form-label">Correct Answer</label><select name="correct_answer" class="form-select" required><option value="" disabled selected>-- Select --</option><option value="A">A</option><option value="B">B</option><option value="C">C</option><option value="D">D</option></select></div>
                    <button type="submit" name="add_question" class="btn btn-primary w-100">Add Question</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Existing Questions List -->
    <div class="col-lg-7">
        <div class="card">
            <div class="card-header"><i class="fas fa-list-ul"></i> Existing Questions for Your Unit</div>
            <div class="card-body">
                <?php
                $stmt = $conn->prepare("SELECT id, question_text FROM questions WHERE unit_id = ? ORDER BY id DESC");
                $stmt->bind_param("i", $unit_id);
                $stmt->execute();
                $questions_result = $stmt->get_result();
                ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead><tr><th>Question</th><th style="width: 100px;">Action</th></tr></thead>
                        <tbody>
                            <?php if ($questions_result->num_rows > 0) : ?>
                                <?php while ($question = $questions_result->fetch_assoc()) : ?>
                                    <tr>
                                        <td><?= htmlspecialchars($question['question_text']) ?></td>
                                        <td>
                                            <form action="manage_quizzes.php" method="post" onsubmit="return confirm('Are you sure?');">
                                                <input type="hidden" name="question_id" value="<?= $question['id'] ?>">
                                                <button type="submit" name="remove_question" class="btn btn-danger btn-sm">Remove</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="2" class="text-center py-4">No questions found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
$conn->close();
include 'includes/footer.php'; 
?>