<?php
// STEP 1: Ensure the user is logged in AND is an admin.
require_once 'includes/session_check.php';
require_role('admin'); 

// STEP 2: Include the database connection.
require_once 'includes/db.php';

$message = '';

// Handle adding a new unit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_unit'])) {
    $unit_name = trim($_POST['unit_name']);
    if (!empty($unit_name)) {
        // Using a prepared statement for security
        $stmt = $conn->prepare("INSERT INTO units (unit_name) VALUES (?)");
        $stmt->bind_param("s", $unit_name);
        if (!$stmt->execute()) {
            // Check for duplicate entry error
            if ($conn->errno == 1062) {
                 $message = '<div class="alert alert-danger">Error: This unit name already exists.</div>';
            } else {
                 $message = '<div class="alert alert-danger">An unknown database error occurred.</div>';
            }
        } else {
             $message = '<div class="alert alert-success">Unit added successfully.</div>';
        }
        $stmt->close();
    }
}

// Handle deleting a unit
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $unit_id_to_delete = $_GET['delete'];
    // Using a prepared statement for security
    $stmt = $conn->prepare("DELETE FROM units WHERE id = ?");
    $stmt->bind_param("i", $unit_id_to_delete);
    $stmt->execute();
    $stmt->close();
    // Redirect to avoid re-deleting on page refresh
    header('Location: manage_units.php');
    exit;
}

// Fetch all units for display. This query is simple and safe.
$units_result = $conn->query("SELECT * FROM units ORDER BY unit_name");

$pageTitle = "Manage Units";
include 'includes/header.php';
include 'includes/sidebar.php';
?>

<h1 class="page-title">Manage EED Units</h1>
<?php if(!empty($message)) echo $message; ?>

<div class="row">
    <!-- Form to add a new unit -->
    <div class="col-md-5 mb-4">
        <div class="card">
            <div class="card-header bg-accent"><i class="fas fa-plus-circle"></i> Add New Unit</div>
            <div class="card-body">
                <form action="manage_units.php" method="post">
                    <div class="mb-3">
                        <label for="unit_name" class="form-label">Unit Name</label>
                        <input type="text" class="form-control" name="unit_name" id="unit_name" required>
                    </div>
                    <button type="submit" name="add_unit" class="btn btn-primary">Add Unit</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Table of existing units -->
    <div class="col-md-7">
        <div class="card">
            <div class="card-header"><i class="fas fa-list-ul"></i> Available Units</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <tbody>
                            <?php 
                            // This check is now safe because $units_result is guaranteed to be a result object or false.
                            if ($units_result && $units_result->num_rows > 0): 
                                while($unit = $units_result->fetch_assoc()): 
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($unit['unit_name']); ?></td>
                                <td class="text-end">
                                    <a href="manage_units.php?delete=<?php echo $unit['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure? Deleting a unit will also delete all associated quizzes, materials, and student enrollments.');">
                                        <i class="fas fa-trash"></i> Delete
                                    </a>
                                </td>
                            </tr>
                            <?php 
                                endwhile; 
                            else:
                            ?>
                            <tr>
                                <td class="text-center">No units have been added yet.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
$conn->close();
include 'includes/footer.php'; 
?>