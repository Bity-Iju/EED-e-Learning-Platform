<?php
require_once 'includes/session_check.php';
require_role('student');
require_once 'includes/db.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) { header('Location: student_dashboard.php'); exit; }
$submission_id = $_GET['id'];
$student_id = $_SESSION['id'];

// --- Fetch all data in a single, efficient query ---
$sql = "SELECT 
            qs.score, qs.submitted_at, qz.title as quiz_title,
            q.id as question_id, q.question_text,
            o.id as option_id, o.option_text, o.is_correct,
            sa.selected_option_id
        FROM quiz_submissions qs
        JOIN quizzes qz ON qs.quiz_id = qz.id
        JOIN questions q ON q.quiz_id = qz.id
        JOIN options o ON o.question_id = q.id
        LEFT JOIN student_answers sa ON sa.question_id = q.id AND sa.submission_id = qs.id
        WHERE qs.id = ? AND qs.student_id = ?
        ORDER BY q.id, o.id";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $submission_id, $student_id);
$stmt->execute();
$result = $stmt->get_result();
if($result->num_rows === 0) { header('Location: student_dashboard.php'); exit; } // Prevent viewing other's results

$quiz_data = [];
$total_questions = 0;
while ($row = $result->fetch_assoc()) {
    if (empty($quiz_data)) {
        $quiz_data['score'] = $row['score'];
        $quiz_data['submitted_at'] = $row['submitted_at'];
        $quiz_data['quiz_title'] = $row['quiz_title'];
    }
    $quiz_data['questions'][$row['question_id']]['question_text'] = $row['question_text'];
    $quiz_data['questions'][$row['question_id']]['selected_option'] = $row['selected_option_id'];
    $quiz_data['questions'][$row['question_id']]['options'][$row['option_id']] = [
        'text' => $row['option_text'],
        'is_correct' => $row['is_correct']
    ];
}
$total_questions = count($quiz_data['questions']);

$pageTitle = "Quiz Result";
include 'includes/header.php';
include 'includes/sidebar.php';
?>

<h1 class="page-title">Result: <?= htmlspecialchars($quiz_data['quiz_title']) ?></h1>

<div class="card mb-4">
    <div class="card-body text-center">
        <h3 class="card-title">Your Score</h3>
        <p class="display-1 fw-bold text-success"><?= $quiz_data['score'] ?> / <?= $total_questions ?></p>
        <p class="text-muted">Submitted on: <?= date('F j, Y, g:i a', strtotime($quiz_data['submitted_at'])) ?></p>
        <a href="take_quiz.php" class="btn btn-primary">Take Another Quiz</a>
    </div>
</div>

<h2 class="mb-3">Detailed Breakdown</h2>

<?php foreach ($quiz_data['questions'] as $question_id => $data): ?>
    <div class="card mb-3">
        <div class="card-header">
            <strong>Question:</strong> <?= htmlspecialchars($data['question_text']) ?>
        </div>
        <ul class="list-group list-group-flush">
            <?php foreach($data['options'] as $option_id => $option): 
                $li_class = '';
                $icon = '';
                // If this is the correct answer
                if ($option['is_correct']) {
                    $li_class = 'list-group-item-success';
                    $icon = '<i class="fas fa-check-circle text-success float-end"></i>';
                }
                // If this is the answer the user selected AND it was wrong
                if ($option_id == $data['selected_option'] && !$option['is_correct']) {
                    $li_class = 'list-group-item-danger';
                    $icon = '<i class="fas fa-times-circle text-danger float-end"></i>';
                }
            ?>
            <li class="list-group-item <?= $li_class ?>">
                <?= htmlspecialchars($option['text']) ?>
                <?= $icon ?>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endforeach; ?>

<?php $conn->close(); include 'includes/footer.php'; ?>