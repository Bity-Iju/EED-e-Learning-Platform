<?php
// STEP 1: INCLUDE THE DATABASE CONNECTION
require_once 'includes/db.php';

$message = ''; // To store feedback for the user

// STEP 2: CHECK IF THE FORM HAS BEEN SUBMITTED
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // STEP 3: GET DATA FROM THE FORM
    $full_name = $_POST['full_name'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role']; // Get the new role field

    // STEP 4: VALIDATE INPUT
    if (empty($full_name) || empty($username) || empty($password) || empty($role)) {
        $message = '<div class="alert alert-danger">All fields are required.</div>';
    } elseif ($role !== 'student' && $role !== 'coordinator') {
        // Security check to ensure role is valid
        $message = '<div class="alert alert-danger">Invalid role selected.</div>';
    } else {
        
        // Handle the 'unit' field based on the selected role
        $unit = null; // Default unit to NULL
        if ($role === 'student') {
            if (empty($_POST['unit'])) {
                $message = '<div class="alert alert-danger">Students must select a unit.</div>';
            } else {
                $unit = $_POST['unit'];
            }
        }

        // Proceed only if the student has selected a unit
        if (empty($message)) {
            // STEP 5: HASH THE PASSWORD FOR SECURITY
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // STEP 6: USE PREPARED STATEMENTS
            // The SQL now includes the 'role' column
            $sql = "INSERT INTO users (full_name, username, password, role, unit) VALUES (?, ?, ?, ?, ?)";
            
            $stmt = $conn->prepare($sql);
            
            if ($stmt === false) {
                die("Error preparing the statement: " . $conn->error);
            }
            
            // Bind the parameters: s = string. There are now 5 parameters.
            $stmt->bind_param("sssss", $full_name, $username, $hashed_password, $role, $unit);
            
            // Execute the statement
            if ($stmt->execute()) {
                $message = '<div class="alert alert-success">Registration successful! You can now <a href="login.php">login</a>.</div>';
            } else {
                if ($conn->errno == 1062) {
                    $message = '<div class="alert alert-danger">Error: This username is already taken.</div>';
                } else {
                    $message = '<div class="alert alert-danger">Error: ' . $stmt->error . '</div>';
                }
            }
            $stmt->close();
        }
    }
    $conn->close();
}
?>

<?php 
    $pageTitle = "Register";
    include 'includes/header.php'; 
?>

<div class="login-container">
    <div class="card login-card" style="max-width: 550px;">
        <div class="card-body p-5">
            <div class="text-center mb-4">
                <h3 class="card-title">Create an Account</h3>
                <p>Join the EED E-Learning Platform</p>
            </div>

            <?php if(!empty($message)) { echo $message; } ?>

            <form action="register.php" method="POST">
                <div class="mb-3">
                    <label for="full_name" class="form-label">Full Name</label>
                    <input type="text" class="form-control" id="full_name" name="full_name" required>
                </div>
                 <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>

                <!-- NEW: Role Selection Field -->
                <div class="mb-3">
                    <label for="role" class="form-label">Register As</label>
                    <select class="form-select" id="role" name="role" required>
                        <option value="" selected disabled>-- Select your role --</option>
                        <option value="student">Student</option>
                        <option value="coordinator">Coordinator</option>
                    </select>
                </div>

                <!-- Unit Selection Field (Conditionally Shown) -->
                <div class="mb-3" id="unit-selection-div" style="display: none;">
                    <label for="unit" class="form-label">Select Your Unit</label>
                    <select class="form-select" id="unit" name="unit">
                        <option value="" selected disabled>-- Choose a unit --</option>
                        <option value="Barbing">Barbing</option>
                        <option value="tailoring">Tailoring</option>
                        <option value="solar installation">Solar Installation</option>
                        <option value="carpentary">Carpentry</option>
                        <option value="hair dressing">Hair Dressing</option>
                    </select>
                </div>

                <div class="d-grid mt-4">
                    <button type="submit" class="btn btn-primary">Register</button>
                </div>
                <div class="text-center mt-3">
                    <a href="login.php">Already have an account? Login</a>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- JAVASCRIPT to show/hide the unit selection -->
<script>
document.getElementById('role').addEventListener('change', function() {
    var unitSelectionDiv = document.getElementById('unit-selection-div');
    var unitSelect = document.getElementById('unit');

    if (this.value === 'student') {
        unitSelectionDiv.style.display = 'block'; // Show the div
        unitSelect.setAttribute('required', 'required'); // Make it a required field
    } else {
        unitSelectionDiv.style.display = 'none'; // Hide the div
        unitSelect.removeAttribute('required'); // Make it not required
    }
});
</script>

<?php include 'includes/footer.php'; ?>