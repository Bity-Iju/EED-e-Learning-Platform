<?php
require_once 'includes/session_check.php';
require_role('student');
require_once 'includes/db.php';

// Get student and unit info from the session and URL
$student_id = $_SESSION['user_id'];
$unit_id = isset($_GET['unit_id']) ? (int)$_GET['unit_id'] : 0;

// Validate that a valid unit was passed in the URL
if ($unit_id === 0) {
    header("Location: student_dashboard.php");
    exit;
}

// --- SECURITY CHECK: Prevent re-taking the quiz ---
$result_check_stmt = $conn->prepare("SELECT id FROM quiz_results WHERE student_id = ? AND unit_id = ?");
$result_check_stmt->bind_param("ii", $student_id, $unit_id);
$result_check_stmt->execute();
if ($result_check_stmt->get_result()->num_rows > 0) {
    // If a result exists, redirect them to the results page immediately.
    header("Location: take_quiz.php");
    exit;
}
$result_check_stmt->close();


// --- HANDLE QUIZ SUBMISSION (when the form is posted) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submitted_answers = $_POST['answers'] ?? [];
    
    // Fetch correct answers from DB to compare against the submission
    $sql_answers = "SELECT id, correct_answer FROM questions WHERE unit_id = ?";
    $stmt_answers = $conn->prepare($sql_answers);
    $stmt_answers->bind_param("i", $unit_id);
    $stmt_answers->execute();
    $result_answers = $stmt_answers->get_result();
    
    $correct_answers = [];
    while ($row = $result_answers->fetch_assoc()) {
        $correct_answers[$row['id']] = $row['correct_answer'];
    }
    $stmt_answers->close();
    
    // Calculate the score
    $score = 0;
    foreach ($correct_answers as $question_id => $correct_option) {
        if (isset($submitted_answers[$question_id]) && $submitted_answers[$question_id] === $correct_option) {
            $score++;
        }
    }
    
    $total_questions = count($correct_answers);
    $percentage = ($total_questions > 0) ? ($score / $total_questions) * 100 : 0;

    // Save the final result to the database
    $insert_stmt = $conn->prepare("INSERT INTO quiz_results (student_id, unit_id, score, total_questions, percentage) VALUES (?, ?, ?, ?, ?)");
    $insert_stmt->bind_param("iiidi", $student_id, $unit_id, $score, $total_questions, $percentage);
    $insert_stmt->execute();
    $insert_stmt->close();

    // --- REDIRECT TO RESULTS PAGE ---
    // After saving, redirect the user back to take_quiz.php, which will now show their score.
    header("Location: take_quiz.php");
    exit;
}


// --- DISPLAY THE QUIZ FORM (if not a POST request) ---
// Fetch unit name and questions
$unit_stmt = $conn->prepare("SELECT unit_name FROM units WHERE id = ?");
$unit_stmt->bind_param("i", $unit_id);
$unit_stmt->execute();
$unit_name = $unit_stmt->get_result()->fetch_assoc()['unit_name'] ?? 'Quiz';
$unit_stmt->close();
$pageTitle = "Quiz: " . htmlspecialchars($unit_name);

// Randomize question order for each attempt
$questions_stmt = $conn->prepare("SELECT * FROM questions WHERE unit_id = ? ORDER BY RAND()");
$questions_stmt->bind_param("i", $unit_id);
$questions_stmt->execute();
$questions = $questions_stmt->get_result();

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<h1 class="page-title"><?= $pageTitle ?></h1>

<?php if ($questions->num_rows > 0): ?>
    <p class="lead">Select one answer for each question below. You cannot change your answers after submitting.</p>
    <form action="start_quiz.php?unit_id=<?= $unit_id ?>" method="post" id="quizForm">
        <?php $q_index = 0; while ($question = $questions->fetch_assoc()): $q_index++; ?>
            <div class="card mb-4 quiz-question-container">
                <div class="card-body">
                    <p class="question-text"><?= $q_index ?>. <?= htmlspecialchars($question['question_text']) ?></p>
                    <div class="options-group">
                        <label class="quiz-option">
                            <span>A) <?= htmlspecialchars($question['option_a']) ?></span>
                            <input type="radio" name="answers[<?= $question['id'] ?>]" value="A" required>
                        </label>
                        <label class="quiz-option">
                            <span>B) <?= htmlspecialchars($question['option_b']) ?></span>
                            <input type="radio" name="answers[<?= $question['id'] ?>]" value="B">
                        </label>
                        <label class="quiz-option">
                            <span>C) <?= htmlspecialchars($question['option_c']) ?></span>
                            <input type="radio" name="answers[<?= $question['id'] ?>]" value="C">
                        </label>
                        <label class="quiz-option">
                            <span>D) <?= htmlspecialchars($question['option_d']) ?></span>
                            <input type="radio" name="answers[<?= $question['id'] ?>]" value="D">
                        </label>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
        <button type="submit" class="btn btn-primary btn-lg w-100">Submit My Answers</button>
    </form>
<?php else: ?>
    <div class="alert alert-info">
        There are no questions available for this unit yet. Please check back later.
    </div>
    <a href="student_dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
<?php endif; ?>

<?php 
$conn->close();
include 'includes/footer.php'; 
?>