<?php
require_once 'includes/session_check.php';
require_role('student');
require_once 'includes/db.php'; // Database connection is now needed for results

$student_id = $_SESSION['user_id'];
$pageTitle = "My Dashboard";

// --- NEW: Fetch quiz history for the student ---
$quiz_history = [];
$sql = "SELECT 
            u.unit_name,
            qr.score,
            qr.total_questions,
            qr.percentage,
            qr.submitted_at
        FROM quiz_results qr
        JOIN units u ON qr.unit_id = u.id
        WHERE qr.student_id = ?
        ORDER BY qr.submitted_at DESC";

if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $quiz_history = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<!-- Use the full name from the session for a more personal welcome -->
<h1 class="page-title">Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?>!</h1>
<p class="lead">This is your personal dashboard. All resources for your registered unit are available below.</p>

<div class="row">
    <!-- Main Unit Card -->
    <div class="col-lg-8 mb-4">
        <div class="card h-100">
            <div class="card-header bg-accent">
                <i class="fas fa-book-open"></i> My Registered Unit
            </div>
            <div class="card-body d-flex flex-column">
                <?php if (isset($_SESSION['unit_id']) && !empty($_SESSION['unit_id'])) : ?>
                    <h3 class="card-title"><?php echo htmlspecialchars($_SESSION['unit_name']); ?></h3>
                    <p class="card-text flex-grow-1">
                        You can access all course materials, including documents and videos, or test your knowledge by taking a quiz for this unit.
                    </p>
                    <div class="mt-auto">
                        <a href="course_materials.php?unit_id=<?php echo $_SESSION['unit_id']; ?>" class="btn btn-primary me-2">
                            <i class="fas fa-file-alt"></i> View Materials
                        </a>
                        <a href="take_quiz.php" class="btn btn-success">
                            <i class="fas fa-question-circle"></i> View My Quiz
                        </a>
                    </div>
                <?php else : ?>
                    <div class="alert alert-warning">
                        You are not currently enrolled in any unit. Please contact an administrator for assistance.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Student Profile Card -->
    <div class="col-lg-4 mb-4">
        <div class="card h-100">
            <div class="card-header">
                <i class="fas fa-user-circle"></i> My Profile
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><strong>Name:</strong><p class="mb-0"><?php echo htmlspecialchars($_SESSION['full_name']); ?></p></li>
                    <li class="list-group-item"><strong>Reg. Number:</strong><p class="mb-0"><?php echo htmlspecialchars($_SESSION['registration_number']); ?></p></li>
                    <li class="list-group-item"><strong>Unit:</strong><p class="mb-0"><?php echo htmlspecialchars($_SESSION['unit_name']); ?></p></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- =============================================== -->
<!-- NEW: Quiz History Table                           -->
<!-- =============================================== -->
<div class="card">
    <div class="card-header">
        <i class="fas fa-history"></i> My Quiz History
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Unit Name</th>
                        <th class="text-center">Score</th>
                        <th class="text-center">Percentage</th>
                        <th>Date Taken</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($quiz_history)): ?>
                        <?php foreach ($quiz_history as $result): ?>
                            <tr>
                                <td><?= htmlspecialchars($result['unit_name']) ?></td>
                                <td class="text-center"><strong><?= (int)$result['score'] ?> / <?= (int)$result['total_questions'] ?></strong></td>
                                <td class="text-center">
                                    <span class="badge bg-success p-2 fs-6"><?= htmlspecialchars(round($result['percentage'])) ?>%</span>
                                </td>
                                <td><?= date('F j, Y - g:i a', strtotime($result['submitted_at'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" class="text-center py-4">You have not completed any quizzes yet.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php 
$conn->close();
include 'includes/footer.php'; 
?>