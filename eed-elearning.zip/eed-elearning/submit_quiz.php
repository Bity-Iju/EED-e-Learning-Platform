<?php
require_once 'includes/session_check.php';
require_once 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['quiz_id'])) {
    header('Location: take_quiz.php');
    exit;
}

$quiz_id = $_POST['quiz_id'];
$student_id = $_SESSION['id'];
$answers = $_POST['answers'] ?? [];
$score = 0;

if (!empty($answers)) {
    // Get all correct option IDs for the submitted answers in one query
    $submitted_option_ids_string = implode(',', array_map('intval', array_values($answers)));
    $sql = "SELECT id FROM options WHERE id IN ($submitted_option_ids_string) AND is_correct = 1";
    $result = $conn->query($sql);
    if ($result) {
        $score = $result->num_rows;
    }
}

// Use a transaction to ensure all data is saved or none at all
$conn->begin_transaction();
try {
    // 1. Save the final submission score
    $stmt_sub = $conn->prepare("INSERT INTO quiz_submissions (quiz_id, student_id, score, submitted_at) VALUES (?, ?, ?, NOW())");
    $stmt_sub->bind_param("iii", $quiz_id, $student_id, $score);
    $stmt_sub->execute();
    $submission_id = $conn->insert_id; // Get the ID of this submission attempt
    $stmt_sub->close();

    // 2. Save each individual answer
    $stmt_ans = $conn->prepare("INSERT INTO student_answers (submission_id, question_id, selected_option_id) VALUES (?, ?, ?)");
    foreach ($answers as $question_id => $selected_option_id) {
        $stmt_ans->bind_param("iii", $submission_id, $question_id, $selected_option_id);
        $stmt_ans->execute();
    }
    $stmt_ans->close();
    
    // 3. If everything was successful, commit the changes
    $conn->commit();
    
} catch (mysqli_sql_exception $exception) {
    $conn->rollback(); // An error occurred, undo all changes
    die("Error processing your quiz. Please try again.");
}

$conn->close();

// Redirect to the new results page, passing the unique submission ID
header("Location: quiz_result.php?id=" . $submission_id);
exit;
?>