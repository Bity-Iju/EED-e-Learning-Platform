<?php
require_once 'includes/session_check.php';
require_role('student');
require_once 'includes/db.php';

// Use the correct session keys set during login
$student_id = $_SESSION['user_id'];
$student_unit_id = $_SESSION['unit_id'];
$student_unit_name = $_SESSION['unit_name'];

$pageTitle = "My Quiz";
$quiz_completed = false;
$result_data = null;

if ($student_unit_id) {
    $sql = "SELECT score, total_questions, percentage, submitted_at 
            FROM quiz_results 
            WHERE student_id = ? AND unit_id = ?";

    $stmt = $conn->prepare($sql);

    // --- THIS IS THE FIX ---
    // Check if the prepare() statement succeeded before trying to use it.
    if ($stmt === false) {
        // If it failed, it's likely because the quiz_results table doesn't exist.
        // Die with a helpful error message instead of a fatal PHP error.
        die("Error preparing the database query. Please ensure the 'quiz_results' table exists. Error: " . htmlspecialchars($conn->error));
    }
    // --- END OF FIX ---

    $stmt->bind_param("ii", $student_id, $student_unit_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $quiz_completed = true;
        $result_data = $result->fetch_assoc();
    }
    $stmt->close();
}

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<h1 class="page-title">Quiz for <?php echo htmlspecialchars($student_unit_name); ?></h1>

<?php if (!$student_unit_id): ?>
    <div class="alert alert-warning">You are not assigned to a unit. Please contact an administrator.</div>

<?php elseif ($quiz_completed): ?>
    <!-- Display the results because the quiz has already been taken -->
    <div class="card shadow-lg">
        <div class="card-header bg-success text-white">
            <i class="fas fa-check-circle"></i> Quiz Completed
        </div>
        <div class="card-body text-center p-5">
            <h2 class="card-title">Your Final Score</h2>
            <p class="display-3 fw-bold text-success mb-0">
                <?= htmlspecialchars(round($result_data['percentage'])) ?>%
            </p>
            <p class="text-muted fs-5 mt-2">
                (You answered <?= (int)$result_data['score'] ?> out of <?= (int)$result_data['total_questions'] ?> questions correctly)
            </p>
            <hr>
            <p class="card-text">
                <strong>Date Taken:</strong> <?= date('F j, Y - g:ia', strtotime($result_data['submitted_at'])) ?>
            </p>
            <a href="student_dashboard.php" class="btn btn-primary mt-3">Back to Dashboard</a>
        </div>
    </div>

<?php else: ?>
    <!-- Display the start button because the quiz has not been taken yet -->
    <p class="lead">You have not yet taken the quiz for your unit. You can only take the quiz once.</p>
    <div class="card">
        <div class="card-header bg-accent">
            <i class="fas fa-play-circle"></i> Begin Your Quiz
        </div>
        <div class="card-body text-center p-5">
            <h3 class="card-title">Ready to test your knowledge?</h3>
            <p>Click the button below to start the quiz for "<?php echo htmlspecialchars($student_unit_name); ?>".</p>
            <div class="my-4">
                <i class="fas fa-question-circle fa-5x text-primary"></i>
            </div>
            <a href="start_quiz.php?unit_id=<?php echo $student_unit_id; ?>" class="btn btn-success btn-lg">
                Start Quiz Now
            </a>
        </div>
    </div>

<?php endif; ?>

<?php 
$conn->close();
include 'includes/footer.php'; 
?>