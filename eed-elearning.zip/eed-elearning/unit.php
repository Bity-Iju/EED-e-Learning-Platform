<?php
require_once 'includes/session_check.php';
require_role('coordinator');

// UPDATED: Use unit_name for display purposes
$coordinator_unit_name = $_SESSION['unit_name'];
$pageTitle = "Dashboard for " . htmlspecialchars($coordinator_unit_name);

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<h1 class="page-title">Unit Dashboard</h1>
<p class="lead">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>.</p>

<div class="card mb-4">
    <div class="card-header bg-accent">
        <i class="fas fa-chalkboard-teacher"></i> Your Assigned Unit
    </div>
    <div class="card-body">
        <h5 class="card-title"><?php echo htmlspecialchars($coordinator_unit_name); ?></h5>
        <p class="card-text">You can manage materials and quizzes for this unit using the sidebar menu.</p>
    </div>
</div>

<div class="row">
    <div class="col-md-6 mb-4">
        <div class="card h-100"><div class="card-body text-center p-4"><i class="fas fa-upload fa-3x text-primary mb-3"></i><h5 class="card-title">Manage Materials</h5><p>Upload, view, and delete course materials for your unit.</p><a href="manage_materials.php" class="btn btn-primary">Manage Materials</a></div></div>
    </div>
     <div class="col-md-6 mb-4">
        <div class="card h-100"><div class="card-body text-center p-4"><i class="fas fa-tasks fa-3x text-primary mb-3"></i><h5 class="card-title">Manage Quizzes</h5><p>Create new quizzes and add questions for your students.</p><a href="manage_quizzes.php" class="btn btn-primary">Manage Quizzes</a></div></div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>