<?php
require_once 'includes/session_check.php';
require_role('admin');
$pageTitle = "Student Scores";
include 'includes/header.php';
include 'includes/sidebar.php';

// Database connection logic should be included here
// For example: require_once 'includes/db_connect.php';

// --- Placeholder for Database Query ---
// You will need to write a query to fetch student scores.
// This is an example assuming you have 'users', 'quizzes', and 'student_scores' tables.
/*
$query = "SELECT u.full_name, q.quiz_title, ss.score
          FROM student_scores ss
          JOIN users u ON ss.student_id = u.id
          JOIN quizzes q ON ss.quiz_id = q.id
          ORDER BY u.full_name, q.quiz_title";
$stmt = $pdo->prepare($query);
$stmt->execute();
$scores = $stmt->fetchAll(PDO::FETCH_ASSOC);
*/

// For demonstration purposes, static data is used here.
$scores = [
    ['full_name' => 'John Doe', 'quiz_title' => 'Introduction to PHP', 'score' => 85],
    ['full_name' => 'Jane Smith', 'quiz_title' => 'Introduction to PHP', 'score' => 92],
    ['full_name' => 'John Doe', 'quiz_title' => 'PHP Functions', 'score' => 78],
    ['full_name' => 'Jane Smith', 'quiz_title' => 'PHP Functions', 'score' => 95],
];

?>

<style>
    @media print {
        body * {
            visibility: hidden;
        }
        #printable-area, #printable-area * {
            visibility: visible;
        }
        #printable-area {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
        }
        .no-print {
            display: none;
        }
    }
</style>

<h1 class="page-title">Student Scores</h1>
<p class="lead">Below is a list of student scores for all quizzes.</p>

<div class="text-right mb-3 no-print">
    <button onclick="window.print();" class="btn btn-primary">Print Scores</button>
</div>

<div id="printable-area">
    <h2>Student Score Report</h2>
    <table class="table table-bordered table-striped">
        <thead class="thead-dark">
            <tr>
                <th>Student Name</th>
                <th>Quiz Title</th>
                <th>Score</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($scores)): ?>
                <?php foreach ($scores as $score): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($score['full_name']); ?></td>
                        <td><?php echo htmlspecialchars($score['quiz_title']); ?></td>
                        <td><?php echo htmlspecialchars($score['score']); ?>%</td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="3" class="text-center">No scores found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'includes/footer.php'; ?>