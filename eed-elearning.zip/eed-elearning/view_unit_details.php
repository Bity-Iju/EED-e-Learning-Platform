<?php
require_once 'includes/session_check.php';
require_role('student');
$pageTitle = "Unit Details";
include 'includes/header.php';
include 'includes/sidebar.php';

// 1. Get Unit ID from URL and validate it's a number
$unit_id = isset($_GET['unit_id']) ? (int)$_GET['unit_id'] : 0;
if ($unit_id === 0) {
    echo "<div class='alert alert-danger'>Invalid unit ID.</div>";
    include 'includes/footer.php';
    exit;
}

// 2. Database connection
// require_once 'includes/db_connect.php';

// --- Database Query Placeholder ---
// This query should fetch the details for the selected unit.
/*
$query = "SELECT unit_name FROM units WHERE id = :unit_id";
$stmt = $pdo->prepare($query);
$stmt->execute(['unit_id' => $unit_id]);
$unit = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$unit) {
    echo "<div class='alert alert-danger'>Unit not found.</div>";
    include 'includes/footer.php';
    exit;
}
*/

// For demonstration, static data is used.
$unit = ['unit_name' => 'Advanced PHP Development'];
?>

<!-- Display the name of the unit at the top -->
<h1 class="page-title"><?php echo htmlspecialchars($unit['unit_name']); ?></h1>
<p class="lead">Access all resources for this unit below.</p>

<div class="row">
    <div class="col-md-6">
        <div class="card text-center h-100">
             <div class="card-body p-4 d-flex flex-column">
                <i class="fas fa-file-alt fa-3x text-primary mb-3"></i>
                <h5 class="card-title">Course Materials</h5>
                <p class="card-text">Access and download all documents, notes, and videos for this unit.</p>
                <!-- This link now includes the unit_id to fetch specific materials -->
                <a href="course_materials.php?unit_id=<?php echo $unit_id; ?>" class="btn btn-primary mt-auto">View Materials</a>
            </div>
        </div>
    </div>
     <div class="col-md-6">
        <div class="card text-center h-100">
             <div class="card-body p-4 d-flex flex-column">
                <i class="fas fa-question-circle fa-3x text-primary mb-3"></i>
                <h5 class="card-title">Quizzes</h5>
                <p class="card-text">Test your knowledge and view your past results for this unit.</p>
                <!-- This link now includes the unit_id to fetch specific quizzes -->
                <a href="take_quiz.php?unit_id=<?php echo $unit_id; ?>" class="btn btn-primary mt-auto">Take a Quiz</a>
            </div>
        </div>
    </div>
</div>

<div class="mt-4">
    <a href="student_dashboard.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
</div>


<?php include 'includes/footer.php'; ?>