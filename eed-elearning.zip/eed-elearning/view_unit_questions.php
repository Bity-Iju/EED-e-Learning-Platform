<?php
require_once 'includes/session_check.php';
require_role('student');
$pageTitle = "Unit Questions";
include 'includes/header.php';
include 'includes/sidebar.php';

// 1. Get Unit ID from URL and validate
$unit_id = isset($_GET['unit_id']) ? (int)$_GET['unit_id'] : 0;
if ($unit_id === 0) {
    echo "<div class='alert alert-danger'>Invalid unit selected.</div>";
    include 'includes/footer.php';
    exit;
}

// 2. Database Connection
// require_once 'includes/db_connect.php';

// --- Database Query Placeholder ---
// This query fetches the unit name and all its questions, grouped by topic.
// It assumes you have 'questions' and 'topics' tables linked to the 'units' table.
/*
$unit_query = "SELECT unit_name FROM units WHERE id = :unit_id";
$unit_stmt = $pdo->prepare($unit_query);
$unit_stmt->execute(['unit_id' => $unit_id]);
$unit = $unit_stmt->fetch(PDO::FETCH_ASSOC);

$questions_query = "SELECT t.topic_name, q.question_text
                    FROM questions q
                    JOIN topics t ON q.topic_id = t.id
                    WHERE q.unit_id = :unit_id
                    ORDER BY t.topic_name, q.id";
$questions_stmt = $pdo->prepare($questions_query);
$questions_stmt->execute(['unit_id' => $unit_id]);
$questions = $questions_stmt->fetchAll(PDO::FETCH_ASSOC);
*/

// For demonstration, we'll use static data. Replace with your database calls.
$unit = ['unit_name' => 'Advanced PHP'];
$questions = [
    ['topic_name' => 'Object-Oriented Programming', 'question_text' => 'What is a class?'],
    ['topic_name' => 'Object-Oriented Programming', 'question_text' => 'Explain inheritance.'],
    ['topic_name' => 'API Integration', 'question_text' => 'What is a REST API?'],
    ['topic_name' => 'API Integration', 'question_text' => 'How do you handle a JSON response?'],
];
$current_topic = null;

?>

<h1 class="page-title">Questions for <?php echo htmlspecialchars($unit['unit_name']); ?></h1>

<div class="questions-container">
    <?php if (!empty($questions)): ?>
        <?php foreach ($questions as $question): ?>
            <?php if ($question['topic_name'] !== $current_topic): ?>
                <?php
                // Close previous topic container if it's not the first one
                if ($current_topic !== null) {
                    echo '</div>';
                }
                $current_topic = $question['topic_name'];
                ?>
                <h3 class="topic-header mt-4"><?php echo htmlspecialchars($current_topic); ?></h3>
                <div class="topic-questions">
            <?php endif; ?>

            <div class="card mb-2">
                <div class="card-body">
                    <?php echo htmlspecialchars($question['question_text']); ?>
                </div>
            </div>

        <?php endforeach; ?>
        </div> <!-- Close the last topic container -->
    <?php else: ?>
        <div class="alert alert-info">No questions have been added for this unit yet.</div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>