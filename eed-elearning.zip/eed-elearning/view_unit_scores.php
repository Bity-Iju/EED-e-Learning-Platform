<?php
require_once 'includes/session_check.php';
require_role('admin');
require_once 'includes/db.php';

// --- Input Validation ---
// Get the unit_id from the URL, ensure it's a number.
$unit_id = isset($_GET['unit_id']) ? (int)$_GET['unit_id'] : 0;

if ($unit_id === 0) {
    // If no valid unit_id is provided, redirect to the dashboard.
    header("Location: admin_dashboard.php");
    exit;
}

// --- Fetch Unit Details ---
$unit_stmt = $conn->prepare("SELECT unit_name FROM units WHERE id = ?");
$unit_stmt->bind_param("i", $unit_id);
$unit_stmt->execute();
$unit_result = $unit_stmt->get_result();
if ($unit_result->num_rows === 0) {
    // If the unit doesn't exist, handle the error.
    $unit_name = "Invalid Unit";
    $scores = [];
} else {
    $unit = $unit_result->fetch_assoc();
    $unit_name = $unit['unit_name'];

    // --- Fetch All Scores for this Unit ---
    $scores_sql = "SELECT 
                        u.full_name,
                        u.registration_number,
                        qr.score,
                        qr.total_questions,
                        qr.percentage,
                        qr.submitted_at
                    FROM quiz_results qr
                    JOIN users u ON qr.student_id = u.id
                    WHERE qr.unit_id = ?
                    ORDER BY qr.percentage DESC, u.full_name ASC";
    
    $scores_stmt = $conn->prepare($scores_sql);
    $scores_stmt->bind_param("i", $unit_id);
    $scores_stmt->execute();
    $scores_result = $scores_stmt->get_result();
    $scores = $scores_result->fetch_all(MYSQLI_ASSOC);
    $scores_stmt->close();
}
$unit_stmt->close();


$pageTitle = "Scores for " . htmlspecialchars($unit_name);
include 'includes/header.php';
include 'includes/sidebar.php';
?>

<!-- ======================= PRINT STYLES ======================= -->
<style>
    @media print {
        /* Hide everything on the page by default */
        body * {
            visibility: hidden;
        }
        /* Make only the printable area and its children visible */
        #printable-area, #printable-area * {
            visibility: visible;
        }
        /* Position the printable area to take up the whole page */
        #printable-area {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
        }
        /* Hide buttons and other non-essential elements when printing */
        .no-print {
            display: none !important;
        }
        .card-header {
            background-color: #f8f9fa !important; /* Lighter header for printing */
            color: #000 !important;
        }
        .table {
            font-size: 12pt;
        }
    }
</style>

<div id="printable-area">
    <h1 class="page-title">Quiz Scores for: <?= htmlspecialchars($unit_name) ?></h1>

    <div class="card shadow">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span><i class="fas fa-users"></i> Student Results</span>
            <div class="no-print">
                <a href="admin_dashboard.php" class="btn btn-sm btn-secondary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
                <button onclick="window.print();" class="btn btn-sm btn-primary"><i class="fas fa-print"></i> Print Scores</button>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover">
                    <thead class="thead-light">
                        <tr>
                            <th>#</th>
                            <th>Student Name</th>
                            <th>Registration No.</th>
                            <th class="text-center">Score</th>
                            <th class="text-center">Percentage</th>
                            <th>Date Submitted</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($scores)): ?>
                            <?php $i = 1; foreach ($scores as $score): ?>
                                <tr>
                                    <td><?= $i++ ?></td>
                                    <td><?= htmlspecialchars($score['full_name']) ?></td>
                                    <td><?= htmlspecialchars($score['registration_number']) ?></td>
                                    <td class="text-center"><strong><?= (int)$score['score'] ?> / <?= (int)$score['total_questions'] ?></strong></td>
                                    <td class="text-center">
                                        <span class="badge fs-6 p-2
                                            <?php 
                                            if ($score['percentage'] >= 70) echo 'bg-success';
                                            elseif ($score['percentage'] >= 40) echo 'bg-warning text-dark';
                                            else echo 'bg-danger';
                                            ?>">
                                            <?= htmlspecialchars(round($score['percentage'])) ?>%
                                        </span>
                                    </td>
                                    <td><?= date('F j, Y, g:i a', strtotime($score['submitted_at'])) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-4">No students have completed the quiz for this unit yet.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php 
$conn->close();
include 'includes/footer.php'; 
?>